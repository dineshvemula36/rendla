import pygame #, time
from math import *
from pygame import *
import geometry, maxHeap, edgesFind

green = 0, 255, 0
nearestNeighbNum = 5
effzero = 0.0001
linkerniter = 50

class HeapVertex:
    def __init__(self,vId,edgelength):
        self.vId = vId
        self.data = edgelength
            
class LinKernighan:
    
    def __init__(self, vertices, screen): #no initialpoint, all are vertices only
        self.vertices = vertices
        self.edges = {} #has to be initialised in main
        self.size = geometry.Vertex.numOfInstance
        self.tour = None #edges is empty right now, have to set when we call findedges function in tsp.py
        self.gStar = 0 #best so far 
        self.screen = screen
    
    def edgeBetween(self,v1,v2):
        if v1<v2:
            return self.edges[str(v1) + '-' + str(v2)].length
        else:
            return self.edges[str(v2) + '-' + str(v1)].length
    
    def findAllEdges(self,rectObs,circleObs,width,height): 
        #we need for initialpoint also - maybe just include it in vertices, no separate initialpoint
        print('find all edges')
#        for v in range(self.size):          
#            for v1 in range(v+1,self.size):
#                print('find edge ' + str(v) + '-' + str(v1))
#                self.edges[str(v) + '-' + str(v1)] = geometry.Edge(self.vertices[v],self.vertices[v1],[self.vertices[v].point,self.vertices[v1].point]) #edgesFind.findEdge(self.vertices[v],self.vertices[v1],rectObs,circleObs,width,height)        
        edgesFind.findEdge(self.vertices,self.edges,rectObs,circleObs,width,height)
   
    def redraw(self):
        for vId in range(self.size):
            #pygame.draw.line(self.screen,green,self.vertices[vId].point,self.vertices[self.tour.tour[vId][0]].point)
            e = None
            if vId<self.tour.tour[vId][1]:
                e = self.edges[str(vId) + '-' + str(self.tour.tour[vId][1])]
            else:
                e = self.edges[str(self.tour.tour[vId][1]) + '-' + str(vId)]
            i=0
            while i<len(e.linkPoints)-1:
                pygame.draw.line(self.screen,green,e.linkPoints[i],e.linkPoints[i+1])
                i=i+1
        pygame.display.set_caption('Min path so far = ' + str(self.tour.tourlength))
        #time.sleep(0.5)
    
    def nearestNeighbours(self,index,tour,brokenlinks): #cant be in formedlinks
        broken = None
        if index in brokenlinks:
            broken = brokenlinks[index]
        heap = maxHeap.MaxHeap()
        i=0
        while i<self.size:
            if i!=index and (i not in tour.tour[index]) and (broken==None or i not in broken):
                if heap.size<nearestNeighbNum:
                    heap.add(HeapVertex(i,self.edgeBetween(i,index)))
                elif heap.peek().data>self.edgeBetween(i,index):
                    heap.pop()
                    heap.add(HeapVertex(i,self.edgeBetween(i,index)))
            i=i+1
        return heap
    
    def flip(self,start,end,tour):
        print('flip')
        while start!=end:
            temp = tour.tour[start][0]
            tour.tour[start][0] = tour.tour[start][1]
            tour.tour[start][1] = temp
            start = temp
        temp = tour.tour[start][0]
        tour.tour[start][0] = tour.tour[start][1]
        tour.tour[start][1] = temp       
        
    def makeChanges(self,t_curr,t_next,t_nnext,t_nnnext,tour): #t_nnnext is fixed for t_curr,t_next,t_nnext
        print('making changes with ' + str(t_curr) + ' ' + str(t_next) + ' ' + str(t_nnext) + ' ' + str(t_nnnext))
        if t_next == tour.tour[t_curr][1]:
            tour.tour[t_curr][1] = t_nnnext #was t_next, t_curr[0] and before not changed
            tour.tour[t_nnext][0] = t_next #was t_nnnext, t_nnext[1] and after not changed
            start = tour.tour[t_nnnext][0]
            end = tour.tour[t_next][1]
            tour.tour[t_next][0] = end
            tour.tour[t_nnnext][1] = start
            tour.tour[t_next][1] = t_nnext
            tour.tour[t_nnnext][0] = t_curr
            if not (start==t_next or end==t_nnnext): #else already flipped
                self.flip(start,end,tour)
        else:
            start = tour.tour[t_nnext][0]
            end = tour.tour[t_curr][1]
            tour.tour[t_nnext][1] = start
            tour.tour[t_curr][0] = end
            tour.tour[t_curr][1] = t_nnnext
            tour.tour[t_nnext][0] = t_next
            tour.tour[t_next][1] = t_nnext #was t_curr, t_next[0] and before not changed
            tour.tour[t_nnnext][0] = t_curr #was t_nnext, t_nnnext[1] and after not changed
            if not (start==t_curr or end==t_nnext): #else already flipped
                self.flip(start,end,tour)
    
    def maxGainPossible(self,t_curr,gainsofar,newtour,brokenlinks,formedlinks):
        #will be called recursively till we get incremental gain -ve or 0 i guess
        #but -ve is not bad if there is huge +ve in next step..
        #overall -ve is bad - like kadane's, we can do same set of changes if we start with this new t_curr w/o doing these changes
        #i think this is why we dont break formed links and vice versa -  so there is a stopping condition - and then we can keep doing several iterations
            
        print('continuing with index = ' + str(t_curr))
        t_next = None #like t2
        prevv = newtour.tour[t_curr][0]
        nextv = newtour.tour[t_curr][1]
        prevvpossible = True
        nextvpossible = True        
        #check if possible to break any of these and return if not
        if prevv in formedlinks and t_curr in formedlinks[prevv]:
            prevvpossible = False
        if nextv in formedlinks and t_curr in formedlinks[nextv]:
            nextvpossible = False
        
        if prevvpossible == False and nextvpossible == False:
            print('cant break anything')
            #not possible to break any xi; conditions 4 c), e) was broken in last step itself
            return geometry.Tour({},0) #make changes so far and return #differentiating from None so no backtracking
            #or maybe return none (not none, empty), if it had been better than gstar it would have been returned anyway
        elif prevvpossible == False:
            t_next = nextv
        elif nextvpossible == False:
            t_next = prevv
        else:        
            if self.edgeBetween(prevv, t_curr) > self.edgeBetween(nextv, t_curr):
                #breaking bigger edge
                t_next = prevv
            else:
                t_next = nextv
        
        nearest = self.nearestNeighbours(t_next,newtour,brokenlinks)
        t_nnnext = None
        t_nnext = None
        g=None
        while nearest.size!=0 and (t_nnnext == None or g+gainsofar<=effzero):
            t_nnnext = None #resetting
            t_nnext = nearest.pop().vId
            if t_next == newtour.tour[t_curr][0]: #t2 prev to t1, then t4 next to t3 - clockwise arrangement in tour array....here it may not be in that order and there is also a possibility, this is being done based on new links right? - no then we wont consider this either
                if not (newtour.tour[t_nnext][1]==t_curr or (newtour.tour[t_nnext][1] in newtour.tour[t_curr]) or ((newtour.tour[t_nnext][1] in brokenlinks) and (t_curr in brokenlinks[newtour.tour[t_nnext][1]])) or ((newtour.tour[t_nnext][1] in formedlinks) and t_nnext in formedlinks[newtour.tour[t_nnext][1]])):
                    #also have to check if t_nnext and t_nnnext has been broken or formed - cannot be in formed links, could be in broken links
                    #for t1-t4 to be in formedlinks - it has to be already adjacent, that should disqualify anyway
                    t_nnnext = newtour.tour[t_nnext][1]
            else: #vice versa condition
                if not (newtour.tour[t_nnext][0]==t_curr or (newtour.tour[t_nnext][0] in newtour.tour[t_curr]) or ((newtour.tour[t_nnext][0] in brokenlinks) and (t_curr in brokenlinks[newtour.tour[t_nnext][0]])) or ((newtour.tour[t_nnext][0] in formedlinks) and t_nnext in formedlinks[newtour.tour[t_nnext][0]])):
                    t_nnnext = newtour.tour[t_nnext][0] 
            if t_nnnext != None:
                print('calc g with ' + str(t_curr) + ' ' + str(t_next) + ' ' + str(t_nnext) + ' ' + str(t_nnnext))
                g=self.edgeBetween(t_curr,t_next) - self.edgeBetween(t_nnext,t_next) -self.edgeBetween(t_curr,t_nnnext)+self.edgeBetween(t_nnext,t_nnnext)
        
        if nearest.size==0 and (t_nnnext==None or g+gainsofar<=effzero):
            print('cant continue with this')
            return geometry.Tour({},0) #differentiating from None for backtracking
        
        if g+gainsofar>self.gStar:
            self.gStar = g+gainsofar
            self.makeChanges(t_curr,t_next,t_nnext,t_nnnext,newtour)
            newtour.tourlength = newtour.tourlength-self.gStar
            print('found better path with G* = ' + str(self.gStar))
            return newtour
        else:
            #t1-t2 broken, t2-t3 formed
            if t_curr in brokenlinks:
                brokenlinks[t_curr].append(t_next)
            else:
                brokenlinks[t_curr] = [t_next]
            if t_next in brokenlinks:
                brokenlinks[t_next].append(t_curr)
            else:
                brokenlinks[t_next] = [t_curr]
            if t_next in formedlinks:
                formedlinks[t_next].append(t_nnext)
            else:
                formedlinks[t_next] = [t_nnext]
            if t_nnext in formedlinks:
                formedlinks[t_nnext].append(t_next)
            else:
                formedlinks[t_nnext] = [t_next]            
            
            if t_nnext in brokenlinks:
                brokenlinks[t_nnext].append(t_nnnext)
            else:
                brokenlinks[t_nnext] = [t_nnnext]
            if t_nnnext in brokenlinks:
                brokenlinks[t_nnnext].append(t_nnext)
            else:
                brokenlinks[t_nnnext] = [t_nnext]
            if t_curr in formedlinks:
                formedlinks[t_curr].append(t_nnnext)
            else:
                formedlinks[t_curr] = [t_nnnext]
            if t_nnnext in formedlinks:
                formedlinks[t_nnnext].append(t_curr)
            else:
                formedlinks[t_nnnext] = [t_curr]
            #flip
            self.makeChanges(t_curr,t_next,t_nnext,t_nnnext,newtour)
            print('continuing with this gain so far g = ' + str(g+gainsofar))
            return self.maxGainPossible(t_nnnext,g+gainsofar,newtour,brokenlinks,formedlinks)
        #return final tour - update tourlength
        
    def maxGainPossibleStepOne(self,t1,t2,newtour): #backtrack possible
        nearest = self.nearestNeighbours(t2,newtour,{})
        g=0
        t3 = 0
        t4 = None
        while nearest.size != 0 and (g<=effzero or t4==None):           
            t4 = None #resetting
            t3 = nearest.pop().vId #these are ids
            print('trying t3 = ' + str(t3))
            if t2 == newtour.tour[t1][1]:
                t4 = newtour.tour[t3][0]
            else:
                t4 = newtour.tour[t3][1]
            #there is a unique t4
            if t4!=None and t4!=t1 and t4 not in newtour.tour[t1]:
                print('trying t4 = ' + str(t4))
                g = self.edgeBetween(t1,t2)-self.edgeBetween(t2,t3)-self.edgeBetween(t1,t4)+self.edgeBetween(t3,t4)
                print('gain = ' + str(g))
            #uniquely determined; criteria is that it should remain tour, not gain                 
        
        if nearest.size==0 and (g<=effzero or t4 == None):
            #backtrack - y1s checked, changing x1
            print('this one not possible')
            return None
        
        if g>self.gStar:
            #terminate this iteration
            #2-opt - 2 broken, 2 replacements  
            self.makeChanges(t1,t2,t3,t4,newtour)
            self.gStar = g
            newtour.tourlength = newtour.tourlength - self.gStar #- why are these not the same??
            print('found better path with G* = ' + str(self.gStar))
            return newtour
        else:
            #t1-t2 broken, t2-t3 formed
            brokenlinks = {}
            formedlinks = {}
            #first time adding, the keys dont exist
            brokenlinks[t1] = [t2]
            brokenlinks[t2] = [t1]
            brokenlinks[t3] = [t4]
            brokenlinks[t4] = [t3]
            formedlinks[t2] = [t3]
            formedlinks[t3] = [t2]
            formedlinks[t1] = [t4]
            formedlinks[t4] = [t1]
            print('continuing with this gain g = ' + str(g))
            #flip
            self.makeChanges(t1,t2,t3,t4,newtour)
            return self.maxGainPossible(t4,g,newtour,brokenlinks,formedlinks)
    
    def startFrom(self,index,newtour): #backtrack possible
        #there is a backtracking step also at i=1,2
        #return tour
        print('t1 is ' + str(index))
        t2 = 0 #right now taking the prev one - or maybe first choose the longer edge to break
        t2alt = 0
        prevv = self.tour.tour[index][0]
        nextv = self.tour.tour[index][1]
        if self.edgeBetween(prevv,index) > self.edgeBetween(nextv,index):
            #breaking bigger edge
            t2 = prevv
            t2alt = nextv
        else:
            t2 = nextv
            t2alt = prevv
        print('t2 chosen: ' + str(t2))
        tr = self.maxGainPossibleStepOne(index,t2,newtour) 
        if tr==None: #but this is doing everything again - not just backtracking at step 1
            print('backtracking to new t2 ' + str(t2alt))
            tr = self.maxGainPossibleStepOne(index,t2alt,newtour)
        #whether or not None return g1
        return tr        
    
    def linKernighan(self):
        #try starting from all nodes bcos they could yield diff results
        vId=0
        numIter = linkerniter
        bestTour = None
        changed = True
        while numIter>0 and changed == True:
            changed = False
            print('numiter = ' + str(linkerniter-numIter))
            while vId<self.size:
                print('starting with vId = ' + str(vId))
                newdict = {}
                for i in range(self.size):
                    newdict[i] = [self.tour.tour[i][0],self.tour.tour[i][1]]
                newtour = geometry.Tour(newdict,self.tour.tourlength)
                btrTour = self.startFrom(vId,newtour)
                if btrTour != None and len(btrTour.tour) != 0: #if btrtour didnt have better tourlength null/empty would be returned
                    bestTour = btrTour
                    changed = True
                vId=vId+1
            #return bestTour
            if changed == True:
                self.tour = bestTour
                self.gStar = 0 #for new tour
                vId = 0
                self.redraw()
            numIter = numIter-1
        print('end at num of iterations = ' + str(linkerniter-numIter))
        d = 0
        i=0
        while i<self.size:
            #d = d+self.edgeBetween(i,self.tour.tour[i][0])
            d = d+self.edgeBetween(i,self.tour.tour[i][1])
            i=i+1
        #d=d/2
        print('length = ' + str(d))
        
