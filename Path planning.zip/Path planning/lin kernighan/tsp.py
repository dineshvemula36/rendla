import sys, time, pygame
from math import *
from pygame import *
import linkern, geometry

rectObs = []
circleObs = []
GAME_LEVEL = 6
XDIM = 720
YDIM = 500
pygame.init()
fpsClock = pygame.time.Clock()
windowSize = [XDIM, YDIM]
screen = pygame.display.set_mode(windowSize)
white = 255, 255, 255
black = 0, 0, 0
gray = 150,150,150
red = 255, 0, 0
green = 0, 255, 0
blue = 0, 0, 255
cyan = 0,180,105
dark_green = 0, 102, 0
GOAL_RADIUS = 10
minImprovement = 0.01 #1%
numIter = 5
#bestTour = None

def dist(p1,p2):     #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def collides(p):    #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def boundary(p):
    #print('boundary checking ' + str(p[0]) + ' ' + str(p[1]))
    if p[0]<=0 or p[0]>=XDIM or p[1]<=0 or p[1]>=YDIM:
        return True
    else:
        return False

def init_obstacles(configNum):  #initialized the obstacle
    global rectObs
    global circleObs
    #print("config "+ str(configNum))
    if (configNum == 0):
        rectObs.append(pygame.Rect((XDIM / 2.0 - 50, YDIM / 2.0 - 100),(100,200)))
    if (configNum == 1):
        rectObs.append(pygame.Rect((100,50),(200,150)))
        rectObs.append(pygame.Rect((400,200),(200,100)))
    if (configNum == 2):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 3):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 4):
        circleObs.append([200,100,100]) 
        circleObs.append([370,300,80])
    if (configNum == 5):
        circleObs.append([370,300,80]) 
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 6):
        rectObs.append(pygame.Rect((247,25),(100,450)))
        rectObs.append(pygame.Rect((373,25),(100,450)))
    if configNum == 7:
        rectObs.append(pygame.Rect((100,200),(50,200)))
        rectObs.append(pygame.Rect((150,200),(100,75)))
        rectObs.append(pygame.Rect((250,200),(50,200)))
        rectObs.append(pygame.Rect((150,325),(40,75)))
        rectObs.append(pygame.Rect((210,325),(40,75)))
        rectObs.append(pygame.Rect((595,25),(100,450)))
    if configNum == 8:
        rectObs = rectObs
        circleObs = circleObs
    if (configNum == 9):
        rectObs.append(pygame.Rect((135,50),(100,400)))
        rectObs.append(pygame.Rect((310,200),(100,200)))
        rectObs.append(pygame.Rect((485,50),(100,400)))
    for rect in rectObs:
        pygame.draw.rect(screen, gray, rect)
    for circle in circleObs:
        pygame.draw.circle(screen, gray, (circle[0],circle[1]), circle[2])

def reset():
    screen.fill(white)
    init_obstacles(GAME_LEVEL)
  
def main():
    goalPoseSet = False
    goalPoints = []
    currentState = 'init'
    lk = None
    reset()
    
    while (True): 
        
        if currentState == 'init':
            print('goal point not yet set')
            pygame.display.set_caption('Select Starting Point and then Goal Point')
            #time.sleep(0.01)
        
        elif currentState == 'findPath':
            pygame.display.set_caption('Min path so far = ' + str(lk.tour.tourlength))
            print('lk start')
            lk.linKernighan()
            currentState = 'pathFound'
        
        elif currentState == 'pathFound': #path found in 2 conditions - if iterations over or if all ants following same path
#            for vId in range(lk.size):
#                pygame.draw.line(screen,green,lk.vertices[vId].point,lk.vertices[lk.tour.tour[vId][0]].point)
#                pygame.draw.line(screen,green,lk.vertices[vId].point,lk.vertices[lk.tour.tour[vId][1]].point)
            screen.fill(white)
            init_obstacles(GAME_LEVEL)
            for g in goalPoints:
                pygame.draw.circle(screen, blue, g.point, GOAL_RADIUS)
            lk.redraw()
            pygame.display.set_caption('Min path found = ' + str(lk.tour.tourlength))
            print('path found')
            
        for e in pygame.event.get():
            if e.type == QUIT or (e.type == KEYUP and e.key == K_ESCAPE):
                sys.exit("Exiting")
            keys = pygame.key.get_pressed()
            if keys[K_SPACE] == True and goalPoseSet == False:
                goalPoseSet = True
                print('goals set')
                lk = linkern.LinKernighan(goalPoints,screen)
                lk.findAllEdges(rectObs, circleObs, XDIM, YDIM)
                randomTour = {}
                i=0
                d=0
                while i<lk.size:
                    randomTour[i] = [0,0]
                    if i==0:
                        randomTour[i][0] = lk.size-1
                    else:
                        randomTour[i][0] = i-1
                    if i==lk.size-1:
                        randomTour[i][1] = 0
                        d = d+lk.edges[str(0)+'-'+str(lk.size-1)].length
                    else:
                        randomTour[i][1] = i+1
                        d = d+lk.edges[str(i)+'-'+str(i+1)].length
                    i=i+1
                #each edge counted twice?
                lk.tour = geometry.Tour(randomTour,d)
                currentState = 'findPath'
            if e.type == MOUSEBUTTONDOWN:
                print('mouse down')
                if currentState == 'init':
                    if goalPoseSet == False:
                        print('goal point set: '+str(e.pos))
                        if collides(e.pos) == False and boundary(e.pos) == False: #also no repetition
                            g = int(e.pos[0]), int(e.pos[1])
                            goalPoints.append(geometry.Vertex(g))
                            pygame.draw.circle(screen, blue, goalPoints[len(goalPoints)-1].point, GOAL_RADIUS)
                else:
                    currentState = 'init'
                    goalPoseSet = False
                    reset()
                    
            pygame.display.update()
            fpsClock.tick(10000)
                    
if __name__ == '__main__':
    main()
                    