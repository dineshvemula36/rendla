import math, sys, pygame, random
import vector
from math import *
from pygame import *

minSpeed = 15
maxSpeed = 20
pherValue = 20

def dist(p1,p2):     #distance between two points
   return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def collides(p,rectObs,circleObs):
    #print('collides checking')
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def boundary(p,width,height):
    #print('boundary checking ' + str(p[0]) + ' ' + str(p[1]))
    if p[0]<=0 or p[0]>=width or p[1]<=0 or p[1]>=height:
        return True
    else:
        return False
    
def lineIntersect(p1,p2,rectObs,circleObs):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False
        
def contains(arr,point):
    #print('loop checking')
    for a in arr:
        if a[0] == point[0] and a[1] == point[1]:
            return True
    return False

class Ant:
    def __init__(self,ID,initialPoint):
        self.ID = ID 
        self.pos = int(initialPoint[0]),int(initialPoint[1])
        self.velocity = vector.Vector.randomVector()
        self.velocity.mult(random.randint(minSpeed,maxSpeed))
        #we actually dont need concept of velocity, it could just be sampling of points
        #if we have velocity, it keeps moving in the same direction till collision
        self.reachedGoal = False
        self.totalDist = 0
        self.path = [self.pos]
        self.lastPathFollowed = None
        self.goalPointsCovered = []
        self.movingBack = False
           
    def optimisePath(self, goalPoints, rectObs, circleObs):
        optimised = True       
        while optimised == True:
            i=len(self.path)-1
            optimised = False
            print("optimising " + str(len(self.path)))            
            while i>1: #at least index i equal to 2 (3 needed for triangulation)
                #print("not reached start node, trying to optimise")
                while i>1 and lineIntersect(self.path[i],self.path[i-2],rectObs,circleObs) == False and contains(goalPoints,self.path[i-1]) == False:
                    #print("can optimise here")
                    self.path.pop(i-1)
                    i = i-1 #new position of i
                    #print('i = ' + str(i))
                    optimised = True #is setting again and again using too much memory?
                i=i-1
                
        #finding btr non goal points
        i=1
        nongoalPoints = []
        while i<len(self.path)-1:
            #if contains(goalPoints,self.path[i]) == False:
            nongoalPoints.append(i)
            i=i+1
        #0th and last index never part of it
        numiter = 5
        #mindiff = 0.05
        for index in nongoalPoints: #for index in range(1,len(self.path)-1) #--?
            min1 = 0.0
            max1 = 1.0
            min2 = 0.0
            max2 = 1.0 #we prob don't need all, can initiate again after this loop
            for k in range(numiter):
                if min1==max1:
                    break
                r = round(random.uniform(min1, max1),3)
                newPoint = int((1-r)*self.path[index-1][0]+r*self.path[index][0]) , int((1-r)*self.path[index-1][1]+r*self.path[index][1])
                if lineIntersect(newPoint, self.path[index+1], rectObs, circleObs) == True:
                    #if r<max1: #always true, that's where we found r
                    min1 = r                   
                elif dist(newPoint,self.path[index-1])+dist(newPoint,self.path[index+1])<dist(self.path[index],self.path[index-1])+dist(self.path[index],self.path[index+1]): #boundary, collides, contains should not happen
                    print("line 1 found btr nongoal pt " + str(-dist(newPoint,self.path[index-1])-dist(newPoint,self.path[index+1])+dist(self.path[index],self.path[index-1])+dist(self.path[index],self.path[index+1])))
                    self.path[index] = newPoint                  
                    max1 = r
            for k in range(numiter):
                if min2==max2:
                    break
                r = round(random.uniform(min2, max2),3)
                newPoint = int((1-r)*self.path[index+1][0]+r*self.path[index][0]) , int((1-r)*self.path[index+1][1]+r*self.path[index][1])
                if lineIntersect(newPoint, self.path[index-1], rectObs, circleObs) == True:
                    #if r<max1: #always true, that's where we found r
                    min2 = r
                elif dist(newPoint,self.path[index-1])+dist(newPoint,self.path[index+1])<dist(self.path[index],self.path[index-1])+dist(self.path[index],self.path[index+1]): #boundary, collides, contains should not happen
                    print("line 2 found btr nongoal pt " + str(-dist(newPoint,self.path[index-1])-dist(newPoint,self.path[index+1])+dist(self.path[index],self.path[index-1])+dist(self.path[index],self.path[index+1])))
                    self.path[index] = newPoint                  
                    max2 = r
        
        i=0
        l=0
        while i<len(self.path)-1:
           l = l+dist(self.path[i],self.path[i+1]) 
           i=i+1
        self.totalDist = l
    
    def move(self,rectObs,circleObs,width,height,pheromoneTrack,gridscale,goalPoint,goalR):
        if (dist(self.pos,goalPoint)<goalR):
            #print("this ant reached goal")
            self.reachedGoal = True
            return       
        
        elif lineIntersect(self.pos,goalPoint,rectObs,circleObs) == False:
            mag = dist(self.pos,goalPoint)
            self.velocity = vector.Vector(goalPoint[0]-self.pos[0],goalPoint[1]-self.pos[1])
            self.velocity.mult(mag) #not limiting to maxSpeed
            self.totalDist = self.totalDist + dist(self.pos,goalPoint)
            self.path.append(goalPoint)
            self.pos = goalPoint          
            #since velocity not updated here, ant has tendency to go back same path if path has only 3 points
            return
        
        x = floor(self.pos[0]/gridscale)
        y = floor(self.pos[1]/gridscale)
        if x<0:
            x=0
        if x>width/gridscale-1:
            x = floor(width/gridscale-1)
        if y<0:
            y=0
        if y>height/gridscale-1:
            y = floor(height/gridscale-1)
        
        if len(pheromoneTrack[x][y]) == 0: #not elif - the others have returned, here the if just before will be counted
            #print('no pheromone')
            nextPos = int(self.pos[0]+self.velocity.x), int(self.pos[1]+self.velocity.y)
            while collides(nextPos,rectObs,circleObs) == True or boundary(nextPos,width,height) == True or lineIntersect(self.pos,nextPos,rectObs,circleObs) == True or contains(self.path,nextPos) == True:
                #print('conditions checked')
                self.velocity = vector.Vector.randomVector()
                self.velocity.mult(random.randint(minSpeed,maxSpeed))
                nextPos = int(self.pos[0]+self.velocity.x), int(self.pos[1]+self.velocity.y)
            self.totalDist = self.totalDist + dist(self.pos,nextPos)
            self.path.append(nextPos)
            self.pos = nextPos
        
        else:
            #print('there is pheromone here')
            r = random.randint(0,len(pheromoneTrack[x][y])-1)
            p = (pheromoneTrack[x][y])[r]
            #p = self.findPosn(pheromoneTrack,x,y)
            nextPos = p
            mag = dist(self.pos,nextPos)
            self.velocity = vector.Vector(nextPos[0]-self.pos[0],nextPos[1]-self.pos[1])
            self.velocity.mult(mag)
            followingPher = True
            #we have to check for collision here, the phervect is for entire grid, may not be appropriate for the actual position
            #boundary and collides nextpos wont be true
            while collides(nextPos,rectObs,circleObs) == True or boundary(nextPos,width,height) == True or lineIntersect(self.pos,nextPos,rectObs,circleObs) == True or contains(self.path,nextPos) == True:
                followingPher = False
                self.velocity = vector.Vector.randomVector()
                self.velocity.mult(random.randint(minSpeed,maxSpeed))
                nextPos = int(self.pos[0]+self.velocity.x), int(self.pos[1]+self.velocity.y)           
            if followingPher == True: #if followingPher then deposit pher
                #pheromoneTrack[x][y].append(Pheromone(p,pherValue))
                i=0
                while i<pherValue:                    
                    pheromoneTrack[x][y].append(p)  
                    i = i+1    
            self.totalDist = self.totalDist + dist(self.pos,nextPos)
            self.path.append(nextPos)
            self.pos = nextPos
        
    def moveBack(self,rectObs,circleObs,nextPos,initialPoint,width,height,gridscale,pheromoneTrack):        
        x = floor(self.pos[0]/gridscale)
        y = floor(self.pos[1]/gridscale)
        nextX = floor(nextPos[0]/gridscale)
        nextY = floor(nextPos[1]/gridscale)
        if x<0:
            x=0
        if x>width/gridscale-1:
            x = floor(width/gridscale)-1
        if y<0:
            y=0
        if y>height/gridscale-1:
            y = floor(height/gridscale)-1
        if nextX<0:
            nextX=0
        if nextX>width/gridscale-1:
            nextX = floor(width/gridscale)-1
        if nextY<0:
            nextY=0
        if nextY>height/gridscale-1:
            nextY = floor(height/gridscale)-1
        #find all int positions in this line
        allGrids = []        
        if nextX == x: #y cant be equal to nextY then - actually could be we have grids not actual positions...in that case we dont append to allGrids
            if nextY > y:
                i = 0
                while y+i<nextY:
                    allGrids.append((x,y+i))
                    i=i+1
            elif nextY < y:
                i = 0
                while y-i>nextY:
                    allGrids.append((x,y-i))
                    i=i+1
        else:           
            if nextY == y: 
                if nextX > x:
                    i = 0
                    while x+i<nextX:
                        allGrids.append((x+i,y))
                        i=i+1
                else: #nextX==x condition already checked
                    i = 0
                    while x-i>nextX:
                        allGrids.append((x-i,y))
                        i=i+1
            else:                      
                if abs(nextX-x)<=abs(nextY-y):
                    if nextX>x:
                        i=0
                        while x+i<nextX:
                            #if ((nextY-y)*(x+i)+(nextX*y-x*nextY))%(nextX-x) == 0: #ie y is an integer for this x..maybe we shouldn't do this check?? - for this x also there will be pher deposited
                            allGrids.append((x+i, int(((nextY-y)*(x+i)+(nextX*y-x*nextY))/(nextX-x))))
                            i=i+1
                    else:
                        i=0
                        while x-i>nextX:
                            #if ((nextY-y)*(x-i)+(nextX*y-x*nextY))%(nextX-x) == 0:
                            allGrids.append((x-i, int(((nextY-y)*(x-i)+(nextX*y-x*nextY))/(nextX-x))))
                            i=i+1
                else:
                    if nextY>y:
                        i=0
                        while y+i<nextY:
                            #if ((nextX-x)*(y+i)+(nextY*x-y*nextX))%(nextY-y) == 0:
                            allGrids.append((int(((nextX-x)*(y+i)+(nextY*x-y*nextX))/(nextY-y)), y+i))
                            i=i+1
                    else:
                        i=0
                        while y-i>nextY:
                            #if ((nextX-x)*(y-i)+(nextY*x-y*nextX))%(nextY-y) == 0:
                            allGrids.append((int(((nextX-x)*(y-i)+(nextY*x-y*nextX))/(nextY-y)), y-i))
                            i=i+1
        #print('going back..')
        for p in allGrids:
            #pheromoneTrack[p[0]][p[1]].append(Pheromone(nextPos,pherValue))
            i=0
            while i<pherValue:                    
                pheromoneTrack[p[0]][p[1]].append(nextPos)  
                i = i+1
        print('pher deposited')
        