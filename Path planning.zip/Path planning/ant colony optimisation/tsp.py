import math, sys, pygame, random
from math import *
from pygame import *
import ant
import time

rectObs = []
circleObs = []
GAME_LEVEL = 6
XDIM = 720
YDIM = 500
pygame.init()
fpsClock = pygame.time.Clock()
windowSize = [XDIM, YDIM]
screen = pygame.display.set_mode(windowSize)
white = 255, 255, 255
black = 0, 0, 0
gray = 150,150,150
red = 255, 0, 0
green = 0, 255, 0
blue = 0, 0, 255
cyan = 0,180,105
dark_green = 0, 102, 0
GOAL_RADIUS = 10
ANT_RADIUS = 3
minImprovement = 0.01 #1%
numIter = 5
percentPherReduced = 0.3
gridscale = 10
pheromoneTrack = []
i=0
while i<floor(XDIM/gridscale):
    pheromoneTrack.append([])
    j=0
    while j<floor(YDIM/gridscale):
        pheromoneTrack[i].append([])
        j = j+1
    i=i+1
#array of vector - vector appears equal to numofants who went there*10(pherValue)
antPopnIter = 0
maxAntPopnIter = 5 #50
antPopnSize = 10 #50
antPopn = []
recordAnt = None

def dist(p1,p2):     #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def collides(p):    #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def lineIntersect(p1,p2):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False

def init_obstacles(configNum):  #initialized the obstacle
    global rectObs
    global circleObs
    rectObs = []
    #print("config "+ str(configNum))
    if (configNum == 0):
        rectObs.append(pygame.Rect((XDIM / 2.0 - 50, YDIM / 2.0 - 100),(100,200)))
    if (configNum == 1):
        rectObs.append(pygame.Rect((100,50),(200,150)))
        rectObs.append(pygame.Rect((400,200),(200,100)))
    if (configNum == 2):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 3):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 4):
        circleObs.append([200,100,100]) 
        circleObs.append([370,300,80])
    if (configNum == 5):
        circleObs.append([370,300,80]) 
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 6):
        rectObs.append(pygame.Rect((247,25),(100,450)))
        rectObs.append(pygame.Rect((373,25),(100,450)))
    if configNum == 7:
        rectObs.append(pygame.Rect((100,200),(50,200)))
        rectObs.append(pygame.Rect((150,200),(100,75)))
        rectObs.append(pygame.Rect((250,200),(50,200)))
        rectObs.append(pygame.Rect((150,325),(40,75)))
        rectObs.append(pygame.Rect((210,325),(40,75)))
        rectObs.append(pygame.Rect((595,25),(100,450)))
    if configNum == 8:
        #nothing
        rectObs = []
        circleObs = []
    for rect in rectObs:
        pygame.draw.rect(screen, gray, rect)
    for circle in circleObs:
        pygame.draw.circle(screen, gray, (circle[0],circle[1]), circle[2])

def reset():
    global antPopn
    screen.fill(white)
    init_obstacles(GAME_LEVEL)
    antPopn = []
    global antPopnIter
    antPopnIter = 0
    
def getGroups(goalPoints):
    connected = {}
    #sets = []
    #setNumber = {}    
    i=0
    while i<len(goalPoints):
        g1 = goalPoints[i]
        if g1 not in connected:
            connected[g1] = []
        j=i+1
        while j<len(goalPoints):
            g2 = goalPoints[j]
            if g2 not in connected:
                connected[g2] = []
            if lineIntersect(g1,g2) == False:
                connected[g1].append(g2) #will be appended in order of their index in goalPoints
                connected[g2].append(g1)
                #sets[g2].append(g1)
            j=j+1
        i=i+1
#    for g in connected:
#        if g not in setNumber:
#            group = []
#            group.add(g)
#            i=0
#            while i<len(connected[g]):
#                j=i+1
#                while j<len(connected[g]):
#                    if connected[g][j] in connected[connected[g][i]]: #if a point belongs to 2 groups, choose bigger group - every point only in 1 group -- we have to check all groups that can be formed and get greatest
#                        group.add()
#                    j=j+1
#                i=i+1
                  
#how do we get groups? within each of the arrays in connected have to find all that are mutually connected, points could get repeated
#how do we find connected components? kosaraju
#2 groups have common points or dont..if they do, we try to merge using those common points and maybe have the soln for entire thing                

def main():
    initPoseSet = False
    initialPoint = None
    goalPoseSet = False
    goalPoints = []
    antsReached = 0
    lastBestPath = 0
    antsDone = []
    optimiseIter = 0
    currentState = 'init'
    reset()
    
    while (True):    
        global antPopn
        global antPopnIter
        screen.fill(white)
        init_obstacles(GAME_LEVEL)
        if initPoseSet == True:
            pygame.draw.circle(screen, red, initialPoint, GOAL_RADIUS)
        for g in goalPoints:
            pygame.draw.circle(screen, blue, g, GOAL_RADIUS)
        for a in antPopn:
            pygame.draw.circle(screen, black, a.pos, ANT_RADIUS)
            time.sleep(0.1)
            if a.lastPathFollowed !=None:
                i=0
                while i<len(a.lastPathFollowed)-1:
                    pygame.draw.line(screen,gray,a.lastPathFollowed[i],a.lastPathFollowed[i+1])
                    i = i+1
                time.sleep(0.05)
        global recordAnt
        if recordAnt != None:
            i=0
            while i<len(recordAnt.path)-1:
                pygame.draw.line(screen,dark_green,recordAnt.path[i],recordAnt.path[i+1],3)
                i = i+1
            time.sleep(0.05)
        
        if currentState == 'init':
            print('goal point not yet set')
            pygame.display.set_caption('Select Starting Point and then Goal Point')
            time.sleep(0.01)
        elif currentState == 'findPath':
            global percentPherReduced
            if recordAnt == None:
                pygame.display.set_caption('Finding path ACO')
            else:
                pygame.display.set_caption('Min path so far: ' + str(recordAnt.totalDist))
            t=0
            while t<len(pheromoneTrack):
                #print('pher evaporating')
                phTrk = pheromoneTrack[t]
                u = 0
                while u<len(phTrk):
                    phT = phTrk[u]
                    i=0
                    #at each point it goes down by percentPherReduced (0.3 here)
                    while i<len(phT)-1:
                        #print('e')
                        j=i
                        count = 0
                        while j<len(phT)-1 and phT[j][0] == phT[j+1][0] and phT[j][1] == phT[j+1][1]:
                            #print('f')
                            count = count+1
                            j = j+1
                        #print('count: ' + str(count))
                        k = 0
                        while k<floor(count*percentPherReduced)+1:
                            #print('g')
                            phT.pop(i)
                            k = k+1
                        i = i+count-k+1
                    u = u+1
                t = t+1
            
            for a in antPopn:
                if a.reachedGoal == True: 
                    if a.ID not in antsDone: #ie reached now - we can do dist check too so can exit if that not true anyway
                        print('this ant reached')
                        antsDone.append(a.ID)
                        antsReached = antsReached+1
                    if a.movingBack == False:
                        a.optimisePath(goalPoints,rectObs,circleObs)
                        a.lastPathFollowed = a.path.copy()                       
                    if recordAnt == None or recordAnt.totalDist>a.totalDist:
                        if recordAnt == None:
                            recordAnt = ant.Ant(antPopnSize+1,a.pos)
                        else:
                            lastBestPath = recordAnt.totalDist
                        #recordAnt.pos = int(a.pos[0]),int(a.pos[1])
                        recordAnt.path = a.lastPathFollowed.copy()
                        recordAnt.totalDist = a.totalDist
                        #velocity,reachedGoal etc not imp                        
                        i=0
                        while i<len(recordAnt.path)-1:
                            pygame.draw.line(screen,green,recordAnt.path[i],recordAnt.path[i+1],3)
                            i = i+1
                        time.sleep(0.05)
                        pygame.display.set_caption('Min path so far: ' + str(recordAnt.totalDist))
                        print('new min path ' + str(recordAnt.totalDist))
                    else:
                        i=0
                        while i<len(a.lastPathFollowed)-1:
                            pygame.draw.line(screen,gray,a.lastPathFollowed[i],a.lastPathFollowed[i+1])
                            i = i+1
                        time.sleep(0.05)
                    #in all cases move back after this
                    s = len(a.path)
                    #if s!=0:
                    nextPos = a.path[s-1]                   
                    if s == 1:
                        print('reached back, resetting')
                        #not making the last path followed gray unless recordant changed right now, will update later
                        a.pos = nextPos
                        a.reachedGoal = False
                        a.totalDist = 0
                        a.movingBack = False
                        #a.path = [self.pos] - already true
                    else:
                        #when s==2 we pop, move to path[0] and deposit pher there
                        a.movingBack = True
                        if len(a.goalPointsCovered)>0 and nextPos[0] == a.goalPointsCovered[len(a.goalPointsCovered)-1][0] and nextPos[1] == a.goalPointsCovered[len(a.goalPointsCovered)-1][1]: #this is true anyway..??
                            a.goalPointsCovered.pop(len(a.goalPointsCovered)-1)
                        a.path.pop(s-1) #last element removed by default
                        a.pos = a.path[s-2]
                        print('ant move back')
                        a.moveBackTsp(rectObs,circleObs,nextPos,XDIM,YDIM,gridscale,pheromoneTrack)
                else:
                    print('ant move further')
                    a.moveTsp(rectObs,circleObs,XDIM,YDIM,pheromoneTrack,gridscale,goalPoints,GOAL_RADIUS)           
            
            if antsReached == antPopnSize:
                print('all ants reached')
                samePath = False
                #if all ants reached, how can lastpathfollowed be none for any -same ant could have reached
                for a in antPopn:
                    for b in antPopn:
                        i=0
                        while i<len(a.lastPathFollowed):
                            if i<len(b.lastPathFollowed) and a.lastPathFollowed[i][0] == b.lastPathFollowed[i][0] and a.lastPathFollowed[i][1] == b.lastPathFollowed[i][1]:
                                samePath = True
                            else:
                                samePath = False
                                break
                            i = i+1
                        if samePath == False:
                            break
                    if samePath == False:
                        break                   
                if samePath == True or antPopnIter>maxAntPopnIter or optimiseIter>=numIter: #if same path, path wont change anymore
                    if samePath == True:
                        print('converged..')
                    if antPopnIter>maxAntPopnIter:
                        print('max iterations reached')
                    if optimiseIter>=numIter:
                        print('no further improvement')
                    currentState = 'pathFound'
                    print('least path found')
                else:
                    if lastBestPath!=0 and (lastBestPath-recordAnt.totalDist)/lastBestPath < minImprovement: #lastbestpath==0 when only 1 min path has been found so far, ie in 1 iteration only 1 best path was found
                        optimiseIter = optimiseIter+1
                    else:
                        optimiseIter=0
                    antsReached = 0
                    antsDone = []
                    antPopnIter = antPopnIter+1
                    print('antPopnIter = ' + str(antPopnIter))
                    currentState = 'findPath'
        elif currentState == 'pathFound': #path found in 2 conditions - if iterations over or if all ants following same path
            pygame.display.set_caption('Least path found: ' + str(recordAnt.totalDist))
            i=0
            while i<len(recordAnt.path)-1:
                pygame.draw.line(screen,cyan,recordAnt.path[i],recordAnt.path[i+1],3)
                i = i+1
            time.sleep(0.05)
            print('path found')
            
        for e in pygame.event.get():
            if e.type == QUIT or (e.type == KEYUP and e.key == K_ESCAPE):
                sys.exit("Exiting")
            keys = pygame.key.get_pressed()
            if keys[K_SPACE] == True and goalPoseSet == False:
                goalPoseSet = True
                i=0
                while i<antPopnSize:
                    antPopn.append(ant.Ant(i,initialPoint))
                    i = i+1
                antPopnIter = antPopnIter+1
                #call function to get linkern of groups of points
                currentState = 'findPath'
            if e.type == MOUSEBUTTONDOWN:
                print('mouse down')
                if currentState == 'init':
                    if initPoseSet == False:
                        if collides(e.pos) == False:
                            print('initiale point set: '+str(e.pos))
                            initialPoint = e.pos
                            initPoseSet = True
                            pygame.draw.circle(screen, red, initialPoint, GOAL_RADIUS)
                    elif goalPoseSet == False:
                        print('goal point set: '+str(e.pos))
                        if collides(e.pos) == False:
                            g = int(e.pos[0]), int(e.pos[1])
                            goalPoints.append(g)
                            pygame.draw.circle(screen, blue, goalPoints[len(goalPoints)-1], GOAL_RADIUS)
                else:
                    currentState = 'init'
                    initPoseSet = False
                    goalPoseSet = False
                    reset()
                    
            pygame.display.update()
            fpsClock.tick(10000)
                    
if __name__ == '__main__':
    main()
                    

