import math, sys, pygame, random
from math import *
from pygame import *
import ant
import time

rectObs = []
circleObs = []
GAME_LEVEL = 9
XDIM = 720
YDIM = 500
pygame.init()
fpsClock = pygame.time.Clock()
windowSize = [XDIM, YDIM]
screen = pygame.display.set_mode(windowSize)
white = 255, 255, 255
black = 0, 0, 0
gray = 150,150,150
red = 255, 0, 0
green = 0, 255, 0
blue = 0, 0, 255
cyan = 0,180,105
dark_green = 0, 102, 0
GOAL_RADIUS = 10
ANT_RADIUS = 3
minImprovement = 0.01 #1%
numIter = 5
percentPherReduced = 0.3
gridscale = 10
pheromoneTrack = []
i=0
while i<floor(XDIM/gridscale):
    pheromoneTrack.append([])
    j=0
    while j<floor(YDIM/gridscale):
        pheromoneTrack[i].append([])
        j = j+1
    i=i+1
#array of vector - vector appears equal to numofants who went there*10(pherValue)
antPopnIter = 0
maxAntPopnIter = 10 #50
antPopnSize = 10 #50
antPopn = []
recordAnt = None

def dist(p1,p2):     #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def collides(p):    #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def init_obstacles(configNum):  #initialized the obstacle
    global rectObs
    global circleObs
    rectObs = []
    #print("config "+ str(configNum))
    if (configNum == 0):
        rectObs.append(pygame.Rect((XDIM / 2.0 - 50, YDIM / 2.0 - 100),(100,200)))
    if (configNum == 1):
        rectObs.append(pygame.Rect((100,50),(200,150)))
        rectObs.append(pygame.Rect((400,200),(200,100)))
    if (configNum == 2):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 3):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 4):
        circleObs.append([200,100,100]) 
        circleObs.append([370,300,80])
    if (configNum == 5):
        circleObs.append([370,300,80]) 
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 6):
        rectObs.append(pygame.Rect((247,25),(100,450)))
        rectObs.append(pygame.Rect((373,25),(100,450)))
    if configNum == 7:
        rectObs.append(pygame.Rect((100,200),(50,200)))
        rectObs.append(pygame.Rect((150,200),(100,75)))
        rectObs.append(pygame.Rect((250,200),(50,200)))
        rectObs.append(pygame.Rect((150,325),(40,75)))
        rectObs.append(pygame.Rect((210,325),(40,75)))
        rectObs.append(pygame.Rect((595,25),(100,450)))
    if configNum == 8:
        rectObs = rectObs
        circleObs = circleObs
    if (configNum == 9):
        rectObs.append(pygame.Rect((135,50),(100,400)))
        rectObs.append(pygame.Rect((310,200),(100,200)))
        rectObs.append(pygame.Rect((485,50),(100,400)))
    for rect in rectObs:
        pygame.draw.rect(screen, gray, rect)
    for circle in circleObs:
        pygame.draw.circle(screen, gray, (circle[0],circle[1]), circle[2])

def reset():
    global antPopn
    screen.fill(white)
    init_obstacles(GAME_LEVEL)
    antPopn = []
    antPopnIter = 0

def main():
    initPoseSet = False
    initialPoint = None
    goalPoseSet = False
    goalPoint = None
    antsReached = 0
    lastBestPath = 0
    antsDone = []
    optimiseIter = 0
    currentState = 'init'
    reset()
    
    while True: 
        global antPopn
        global antPopnIter
        screen.fill(white)
        init_obstacles(GAME_LEVEL)
        if initPoseSet == True:
            pygame.draw.circle(screen, red, initialPoint, GOAL_RADIUS)
        if goalPoseSet == True:
            pygame.draw.circle(screen, blue, goalPoint, GOAL_RADIUS)
        for a in antPopn:
            pygame.draw.circle(screen, black, a.pos, ANT_RADIUS)
            time.sleep(0.01)
            if a.lastPathFollowed !=None:
                i=0
                while i<len(a.lastPathFollowed)-1:
                    pygame.draw.line(screen,gray,a.lastPathFollowed[i],a.lastPathFollowed[i+1])
                    i = i+1
                time.sleep(0.01)
        global recordAnt
        if recordAnt != None:
            i=0
            while i<len(recordAnt.path)-1:
                pygame.draw.line(screen,dark_green,recordAnt.path[i],recordAnt.path[i+1],3)
                i = i+1
            time.sleep(0.01)
        if currentState == 'init':
            print('goal point not yet set')
            pygame.display.set_caption('Select Starting Point and then Goal Point')
            time.sleep(0.01)
        elif currentState == 'findPath':
            global percentPherReduced
            if recordAnt == None:
                pygame.display.set_caption('Finding path ACO')
            else:
                pygame.display.set_caption('Min path so far: ' + str(recordAnt.totalDist))
            t=0
            while t<len(pheromoneTrack):
                #print('pher evaporating')
                phTrk = pheromoneTrack[t]
                u = 0
                while u<len(phTrk):
                    phT = phTrk[u]
                    i=0
                    #at each point it goes down by percentPherReduced (0.3 here)
                    while i<len(phT)-1:
                        #print('e')
                        j=i
                        count = 0
                        while j<len(phT)-1 and phT[j][0] == phT[j+1][0] and phT[j][1] == phT[j+1][1]:
                            #print('f')
                            count = count+1
                            j = j+1
                        #print('count: ' + str(count))
                        k = 0
                        while k<floor(count*percentPherReduced)+1:
                            #print('g')
                            phT.pop(i)
                            k = k+1
                        i = i+count-k+1
                    u = u+1
                t = t+1
            
            for a in antPopn:
                if a.reachedGoal == True: 
                    if a.ID not in antsDone: #ie reached now - we can do dist check too so can exit if that not true anyway
                        print('this ant reached')
                        antsDone.append(a.ID)
                        antsReached = antsReached+1
                    if a.movingBack == False:
                        a.optimisePath([goalPoint],rectObs,circleObs)
                        a.lastPathFollowed = a.path.copy()                       
                    if recordAnt == None or recordAnt.totalDist>a.totalDist:
                        if recordAnt == None:
                            recordAnt = ant.Ant(antPopnSize+1,a.pos)
                        else:
                            lastBestPath = recordAnt.totalDist
                        recordAnt.pos = int(a.pos[0]),int(a.pos[1])
                        recordAnt.path = a.lastPathFollowed.copy()
                        print('pathfollowed length: ' + str(len(a.path))) #even if same ant btr pth while going back, it gets updated here only
                        #if len(a.path) == 1:
                         #   print(str(a.path[0][0]) + ' ' + str(a.path[0][1]) + ' ' + str(initialPoint[0]) + ' ' + str(initialPoint[1]))
                        recordAnt.totalDist = a.totalDist
                        #velocity,reachedGoal etc not imp                        
                        i=0
                        while i<len(recordAnt.path)-1:
                            pygame.draw.line(screen,green,recordAnt.path[i],recordAnt.path[i+1],3)
                            i = i+1
                        time.sleep(0.01)
                        pygame.display.set_caption('Min path so far: ' + str(recordAnt.totalDist))
                        print('new min path ' + str(recordAnt.totalDist))
                    else:
                        i=0
                        while i<len(a.lastPathFollowed)-1:
                            pygame.draw.line(screen,gray,a.lastPathFollowed[i],a.lastPathFollowed[i+1])
                            i = i+1
                        time.sleep(0.01)
                    #in all cases move back after this
                    s = len(a.path)
                    nextPos = a.path[s-1]                   
                    if s == 1:
                        print('reached back, resetting')
                        #if recordAnt.totalDist>a.totalDist: #we dont need to check recordant = none condition
                         #   recordAnt.path = a.lastPathFollowed.copy()
                          #  print('lastpathfollowed length: ' + str(len(a.lastPathFollowed)))
                          #lastBestPath = recordAnt.totalDist
                        #    recordAnt.totalDist = a.totalDist
                         #   i=0
                          #  while i<len(recordAnt.path)-1:
                           #     pygame.draw.line(screen,green,recordAnt.path[i],recordAnt.path[i+1],3)
                            #    i = i+1
                            #time.sleep(0.01)
                            #pygame.display.set_caption('Min path so far: ' + str(recordAnt.totalDist))
                            #print('new min path ' + str(recordAnt.totalDist))
                        #else:
                         #   i=0
                          #  while i<len(a.lastPathFollowed)-1:
                           #     pygame.draw.line(screen,gray,a.lastPathFollowed[i],a.lastPathFollowed[i+1])
                            #    i = i+1
                            #time.sleep(0.01)
                        #not making the last path followed gray unless recordant changed right now, will update later
                        a.pos = nextPos
                        a.reachedGoal = False
                        a.totalDist = 0
                        a.movingBack = False
                        #a.path = [self.pos] - already true
                    else:
                        #when s==2 we pop, move to path[0] and deposit pher there
                        a.movingBack = True
                        a.path.pop(s-1) #last element removed by default
                        a.pos = a.path[s-2]
                        print('ant move back')
                        a.moveBack(rectObs,circleObs,nextPos,initialPoint,XDIM,YDIM,gridscale,pheromoneTrack)
                else:
                    print('ant move further')
                    a.move(rectObs,circleObs,XDIM,YDIM,pheromoneTrack,gridscale,goalPoint,GOAL_RADIUS)           
            
            if antsReached == antPopnSize:
                print('all ants reached')
                samePath = False
                #if all ants reached, how can lastpathfollowed be none for any -same ant could have reached
                for a in antPopn:
                    for b in antPopn:
                        i=0
                        while i<len(a.lastPathFollowed):
                            if i<len(b.lastPathFollowed) and a.lastPathFollowed[i][0] == b.lastPathFollowed[i][0] and a.lastPathFollowed[i][1] == b.lastPathFollowed[i][1]:
                                samePath = True
                            else:
                                samePath = False
                                break
                            i = i+1
                        if samePath == False:
                            break
                    if samePath == False:
                        break                   
                if samePath == True or antPopnIter>maxAntPopnIter or optimiseIter>=numIter: #if same path, path wont change anymore
                    if samePath == True:
                        print('converged..')
                    if antPopnIter>maxAntPopnIter:
                        print('max iterations reached')
                    if optimiseIter>=numIter:
                        print('no further improvement')
                    currentState = 'pathFound'
                    print('least path found')
                else:
                    if lastBestPath!=0 and (lastBestPath-recordAnt.totalDist)/lastBestPath < minImprovement: #lastbestpath==0 when only 1 min path has been found so far, ie in 1 iteration only 1 best path was found
                        optimiseIter = optimiseIter+1
                    else:
                        optimiseIter=0
                    antsReached = 0
                    antsDone = []
                    antPopnIter = antPopnIter+1
                    print('antPopnIter = ' + str(antPopnIter))
                    currentState = 'findPath'
        
        elif currentState == 'pathFound': #path found in 2 conditions - if iterations over or if all ants following same path
            pygame.display.set_caption('Least path found: ' + str(recordAnt.totalDist))
            i=0
            while i<len(recordAnt.path)-1:
                pygame.draw.line(screen,cyan,recordAnt.path[i],recordAnt.path[i+1],3)
                i = i+1
            time.sleep(0.01)
            print('path found')
        for e in pygame.event.get():
                if e.type == QUIT or (e.type == KEYUP and e.key == K_ESCAPE):
                    sys.exit("Exiting")
                if e.type == MOUSEBUTTONDOWN:
                    print('mouse down')
                    if currentState == 'init':
                        if initPoseSet == False:
                            if collides(e.pos) == False:
                                print('initiale point set: '+str(e.pos))
                                initialPoint = e.pos
                                initPoseSet = True
                                pygame.draw.circle(screen, red, initialPoint, GOAL_RADIUS)
                        elif goalPoseSet == False:
                            print('goal point set: '+str(e.pos))
                            if collides(e.pos) == False:
                                goalPoint = e.pos
                                goalPoseSet = True
                                pygame.draw.circle(screen, blue, goalPoint, GOAL_RADIUS)
                                i=0
                                while i<antPopnSize:
                                    antPopn.append(ant.Ant(i,initialPoint))
                                    i = i+1
                                antPopnIter = antPopnIter+1
                                currentState = 'findPath'
                    else:
                        currentState = 'init'
                        initPoseSet = False
                        goalPoseSet = False
                        reset()
                        
        pygame.display.update()
        fpsClock.tick(10000)
                    
if __name__ == '__main__':
    main()
                    
