import math, random
from random import randint
from math import *

class Vector:        
    def __init__(self,x,y):
        if x == 0 and y == 0:
            self.x = 0
            self.y = 0
        else:
            self.x = round(x/sqrt(x*x + y*y),3)
            self.y = round(y/sqrt(x*x + y*y),3)
    
    @staticmethod
    def randomVector():
        x = int(random.randint(-10,10))
        y = int(random.randint(-10,10))
        while x == 0 and y == 0:
           x = int(random.randint(-10,10))
           y = int(random.randint(-10,10)) 
        v = Vector(x,y)
        #print(str(v.x) + " " + str(v.y))
        return v
    
    def mult(self,scalar):
        self.x = self.x*scalar
        self.y = self.y*scalar
    
    def add(self,vect):
        self.x = self.x + vect.x
        self.y = self.y + vect.y

    def subtract(self,vect):
        self.x = self.x-vect.x
        self.y = self.y-vect.y
     
    def limit(self,mag):
        if sqrt(self.x*self.x + self.y*self.y)>mag:
            self.x = mag*self.x/sqrt(self.x*self.x+self.y*self.y)
            self.y = mag*self.y/sqrt(self.x*self.x+self.y*self.y)