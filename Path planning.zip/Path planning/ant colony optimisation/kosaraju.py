import queue

def kosaraju(goalPoints,adjacencyList):
    #do dfs, put into another stack once u pop out of dfs stack, then take out of that stack and do dfs again on each
    s1 = queue.LifoQueue(maxsize=len(goalPoints))
    s2 = queue.LifoQueue(maxsize=len(goalPoints))
    visited1 = {}
    current = goalPoints[0]
    s1.put(current)
    visited1[current] = True
    while s1.empty() == False: #assuming graph has no disconnected components
        for g in adjacencyList[current]:
            if g not in visited1:
                break
        if g not in visited1:
            current = g
            visited1[g] = True
        else:
            s2.put(s1.pop())
            if s1.empty() == False:
                current = s1.pop()
                s1.put(current) #there is no peek function
    visited2 = {} #could have reused visited1 by removing from visited1 this time so checking if it doesnt exist in visited1 instead of if it does
    while s2.empty() == False:
        current = s2.pop()
        while current in visited2 and s2.empty() == False:
            current = s2.pop()
        s1.put(current)
        visited2[current] = True
        while s1.empty() == False:
            #what happens here just normal dfs?? or are we checking from stack2 if that is adjacent or something
            