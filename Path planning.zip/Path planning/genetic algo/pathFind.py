import math, sys, pygame, random
from math import *
from pygame import *
import population
import time

rectObs = []
circleObs = []
GAME_LEVEL = 1
XDIM = 720
YDIM = 500
pygame.init()
fpsClock = pygame.time.Clock()
windowSize = [XDIM, YDIM]
screen = pygame.display.set_mode(windowSize)
white = 255, 255, 255
black = 0, 0, 0
gray = 150,150,150
red = 255, 0, 0
green = 0, 255, 0
blue = 0, 0, 255
cyan = 0,180,105
dark_green = 0, 102, 0
GOAL_RADIUS = 10
PARTICLE_RADIUS = 3

gridscale = 10
lifetime = XDIM/3
timer = 0
recordTime = lifetime
dnasize = floor(XDIM/gridscale)*floor(YDIM/gridscale)
popnSize = 500
mutationRate = 0.02
maxGenerations = 10
recordParticle = None
popn = None

def dist(p1,p2):     #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def collides(p):    #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def init_obstacles(configNum):  #initialized the obstacle
    global rectObs
    global circleObs
    rectObs = []
    #print("config "+ str(configNum))
    if (configNum == 0):
        rectObs.append(pygame.Rect((XDIM / 2.0 - 50, YDIM / 2.0 - 100),(100,200)))
    if (configNum == 1):
        rectObs.append(pygame.Rect((100,50),(200,150)))
        rectObs.append(pygame.Rect((400,200),(200,100)))
    if (configNum == 2):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 3):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 4):
        circleObs.append([200,100,100]) 
        circleObs.append([370,300,80])
    if (configNum == 5):
        circleObs.append([370,300,80]) 
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 6):
        rectObs.append(pygame.Rect((247,25),(100,450)))
        rectObs.append(pygame.Rect((373,25),(100,450)))
    if configNum == 7:
        rectObs.append(pygame.Rect((100,200),(50,200)))
        rectObs.append(pygame.Rect((150,200),(100,75)))
        rectObs.append(pygame.Rect((250,200),(50,200)))
        rectObs.append(pygame.Rect((150,325),(40,75)))
        rectObs.append(pygame.Rect((210,325),(40,75)))
        rectObs.append(pygame.Rect((595,25),(100,450)))
        
    for rect in rectObs:
        pygame.draw.rect(screen, gray, rect)
    for circle in circleObs:
        pygame.draw.circle(screen, gray, (circle[0],circle[1]), circle[2])

def reset():
    global timer
    screen.fill(white)
    init_obstacles(GAME_LEVEL)
    timer = 0

def main():
    initPoseSet = False
    initialPoint = None
    goalPoseSet = False
    goalPoint = None
    currentState = 'init'
    reset()
    
    while True:    
        global popn
        screen.fill(white)
        init_obstacles(GAME_LEVEL)
        if initPoseSet == True:
            pygame.draw.circle(screen, red, initialPoint, GOAL_RADIUS)
        if goalPoseSet == True:
            pygame.draw.circle(screen, blue, goalPoint, GOAL_RADIUS)
        if popn != None:
            for p in popn.popn:
                pygame.draw.circle(screen, black, p.pos, PARTICLE_RADIUS)
            time.sleep(0.01)
        if currentState == 'init':
            print('goal point not yet set')
            pygame.display.set_caption('Select Starting Point and then Goal Point')
            time.sleep(0.01)
        elif currentState == 'findPath':
            global timer
            global lifetime
            global recordTime
            global maxGenerations
            global recordParticle
            if popn.generations<maxGenerations:
                if timer<lifetime:
                    popn.generationLive(rectObs,circleObs,goalPoint,GOAL_RADIUS,gridscale,YDIM,XDIM)
                    if popn.generationDone(goalPoint,GOAL_RADIUS) == True:
                        if recordTime>timer:
                            recordTime = timer
                        #if all hv reached, next generation
                        timer = 0
                        popn.setFitnessValue(goalPoint,GOAL_RADIUS)
                        popn.naturalSelection()
                        popn.generate(initialPoint)
                    timer = timer+1
                else:
                    timer = 0
                    popn.setFitnessValue(goalPoint,GOAL_RADIUS)
                    if recordParticle == None or popn.bestParticle.finish<recordParticle.finish:
                        recordParticle = popn.bestParticle
                    i=0
                    while i<len(recordParticle.path-1):
                        pygame.draw.line(screen,dark_green,recordParticle.path[i],recordParticle.path[i+1])
                        i = i+1
                    time.sleep(0.01)
                    popn.naturalSelection()
                    popn.generate(initialPoint)
            else:
                currentState = 'pathFound'
        elif currentState == 'pathFound':
            i=0
            while i<len(recordParticle.path-1):
                pygame.draw.line(screen,red,recordParticle.path[i],recordParticle.path[i+1])
                i = i+1
            time.sleep(0.01)
        for e in pygame.event.get():
                if e.type == QUIT or (e.type == KEYUP and e.key == K_ESCAPE):
                    sys.exit("Exiting")
                if e.type == MOUSEBUTTONDOWN:
                    print('mouse down')
                    if currentState == 'init':
                        if initPoseSet == False:
                            nodes = []
                            if collides(e.pos) == False:
                                print('initiale point set: '+str(e.pos))
                                initialPoint = e.pos
                                nodes.append(initialPoint)
                                initPoseSet = True
                                pygame.draw.circle(screen, red, initialPoint, GOAL_RADIUS)
                        elif goalPoseSet == False:
                            print('goal point set: '+str(e.pos))
                            if collides(e.pos) == False:
                                #global popn
                                goalPoint = e.pos
                                goalPoseSet = True
                                pygame.draw.circle(screen, blue, goalPoint, GOAL_RADIUS)
                                popn = population.Population(mutationRate,popnSize,initialPoint,dnasize)
                                currentState = 'findPath'
                    else:
                        currentState = 'init'
                        initPoseSet = False
                        goalPoseSet = False
                        reset()
                        
        pygame.display.update()
        fpsClock.tick(10000)
                    
if __name__ == '__main__':
    main()
                    
