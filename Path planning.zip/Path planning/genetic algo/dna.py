import math
import vector
from math import *

class DNA:    
    def __init__(self,num,genes = []):
        if genes == []:
            self.genes = []
            i=0
            while i<num:
                genes.append(vector.Vector.randomVector())
                i = i+1
        else:
            self.genes = genes
    
    def crossover(self,partner, f1, f2):
        child = []
        #take half from 1 and half from other or some random number?? or weighted?? - we can hv weighted by passing 2 fitness values and choosing genes acc 
        #picking weighted here acc to fitness values
        a = int((f1/(f1+f2))*len(self.genes))
        i=0
        while i<len(self.genes):
            if i<a:
                child.append(self.genes[i])
            else:
                child.append(partner.genes[i])
            i = i+1
        
        return DNA(len(child),child)
    
    def mutate(self,m):
        #m is mutation rate
        i=0
        while i<len(self.genes):
            if random.random()<m:
                self.genes[i] = vector.Vector.randomVector()
            i = i+1
            