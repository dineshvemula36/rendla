import math, random
from random import randint
import particle
import dna

class Population:
    def __init__(self,m,size,initialPos,dnasize):
        self.mutationRate = m
        self.popn = []
        self.darwin = []
        self.generations = 0
        i=0
        while i<size:
            self.popn.append(particle.Particle(initialPos,dna.DNA(dnasize)))
            i = i+1
        self.order = 1
        self.bestParticle = None
        
    def generationLive(self,rectObs,circleObs,goal,goalR,gridscale,height,width):
        popnRecord = 100000
        for p in self.popn:
            if p.finished(goal,goalR):
                p.finish = self.order
                if self.order == 1:
                    self.bestParticle = p
                self.order = self.order+1
            p.run(rectObs,circleObs,goal,goalR,gridscale,height,width)
            if p.recordDist<popnRecord:
                popnRecord = p.recordDist

    def generationDone(self,goal,goalR):
        for p in self.popn:
            if p.finished(goal,goalR) == False:
                return False
        return True
    
    def setFitnessValue(self,goal,goalR):
        for p in self.popn:
            p.calcFitness(goal,goalR)
        self.order = 1 #resetting to 1 for next generation
        
    #mating pool
    def naturalSelection(self):
        self.darwin = []
        totalFitness = 0   
        #we could have avg fitness value, only ones with more than avg fitness become part of mating pool
        for p in self.popn:
            totalFitness = totalFitness + p.fitness
        for p in self.popn:
            numAppears = int((p.fitness/totalFitness)*500000) #arbitrary - hv to see
            i=0
            while i<numAppears:
                self.darwin.append(p)
                i = i+1
    
    #next generation
    def generate(self,initialPos):
        i=0
        while i<len(self.popn):
            m = random.randint(0,len(self.darwin))
            d = random.randint(0,len(self.darwin))
            mom = self.darwin[m]
            dad = self.darwin[d]
            child = mom.dna.crossover(dad.dna,mom.fitness,dad.fitness)
            child.mutate(self.mutationRate)
            self.popn[i] = particle.Particle(initialPos,child)
            i = i+1
        self.generations = self.generations+1
            