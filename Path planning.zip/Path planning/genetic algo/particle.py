import math, sys, pygame, random
import vector
from math import *
from pygame import *

#fix - can have position = point in pygame  
def dist(p1,p2):     #distance between two points
   return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))
    
    #fix    
def collides(p,rectObs,circleObs):
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

class Particle:
    def __init__(self, pos, dna):
        self.acceleration = vector.Vector.randomVector()
        self.velocity = vector.Vector.randomVector()
        self.pos = pos
        self.dna = dna
        self.stopped = False
        self.dead = False
        self.finish = 1000000
        self.recordDist = float("inf")
        self.fitness = 0
        self.maxSpeed = 5.0
        self.maxAccn = 1.0
        self.path = [self.pos]
    
    def calcFitness(self,goal,goalR):
        if self.dead == True:
            self.fitness = 0
        else:
            d = dist(self.lastPos,goal)
            if d<goalR:
                d = 1.0
            self.fitness = (1/pow(self.finish,1.5))*(1/pow(d,6))
        
    def borderDead(self,height,width):
        if self.pos[0] < 0 or self.pos[0] > width or self.pos[1] < 0 or self.pos[1] > height:
            return True
        else:
            return False
    
    def checkObs(self,rectObs,circleObs):
        if collides(self.pos,rectObs,circleObs):
            return True
        else:
            return False
        
    def finished(self,goal,goalR):
        if dist(self.pos,goal)<self.recordDist:
            self.recordDist = dist(self.pos,goal)  
        if self.dead == True:
            return True
        elif dist(self.pos,goal)<goalR:
            self.stopped = True
            return True
        else:
            return False
    
    def update(self,goal,goalR,gridscale,height,width):
        if self.finished(goal,goalR) == False:
            x = floor(self.pos[0]/gridscale)
            y = floor(self.pos[1]/gridscale)
            if x<0:
                x=0
            if x>width/gridscale-1:
                x = width/gridscale-1
            if y<0:
                y=0
            if y>height/gridscale-1:
                y = height/gridscale-1
            
            desired = vector.Vector(self.genes[int(x+y*(width/gridscale))].x,self.genes[int(x+y*(width/gridscale))].y)
            desired.mult(self.maxSpeed)
            steer = desired.subtract(self.velocity)
            self.acceleration.add(steer)
            self.acceleration.limit(self.maxAccn)
            self.velocity.add(self.acceleration)
            self.velocity.limit(self.maxSpeed)           
            nextPos = self.pos[0]+self.velocity.x + self.pos[1]+self.velocity.y
            self.path.appen(nextPos)
            self.pos = nextPos
            self.acceleration.mult(0)
       
        
    def run(self,rectObs,circleObs,goal,goalR,height,width,gridscale):
        if self.stopped == False:
            self.update(goal,goalR,gridscale,height,width)
            if self.borderDead() or self.checkObs(rectObs,circleObs):
                self.stopped = True
                self.dead = True
                