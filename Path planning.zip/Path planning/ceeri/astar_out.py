#!/usr/bin/env python
import pygame,sys,random,math
from pygame.locals import *
import numpy as np
from math import *

def dist(p1,p2):     #distance between two points
   return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def astar(map_grid,start,goal,mapwidth,mapheight):
    closed_list=[]
    open_list=[]
    path=[]
    current_index=0
    hues_temp=abs(start[0]-goal[0])+abs(start[1]-goal[1])
    current_node=(start[0],start[1],start[0],start[1],hues_temp,current_index)
        
    open_list.append(current_node)
    
    while len(open_list)>0:
          frontier=child(current_node,map_grid,mapwidth,mapheight,closed_list,current_node,goal,open_list)
          for node in frontier:
              flag=0
              for open_pos in open_list:
                   if node[0] == open_pos[0] and node[1] == open_pos[1]:
                      flag=1
              if flag==0:
                 open_list.append(node)        
          
          print(current_node)
          
          closed_list.append(current_node)
          open_list.remove(current_node)
          min_hue=open_list[0][4]
          min_node=open_list[0]
          for pos in range(len(open_list)):
              if open_list[pos][4]<min_hue:
                 min_hue=open_list[pos][4]
                 min_node=open_list[pos]
          current_node=min_node
          
          if current_node[0]==goal[0] and current_node[1]==goal[1]:
             closed_list.append(current_node)
             open_list.remove(current_node)
             break
          
    print (closed_list)
    path = []
    current = (current_node[0],current_node[1])
    present=current_node
    #start_node=(start[0],start[1])
    while current != start:
          path.append(current)
          print (start)
          print ("how")
          for pos in range(len(closed_list)):
              if closed_list[pos][0]==present[2] and closed_list[pos][1]==present[3]:
                 current=(closed_list[pos][0],closed_list[pos][1])
                 
                 print (current)
                 present=closed_list[pos]
                 print ("wow")
                 print (present)
                 break
    return path[::-1]
    
def child(node,map_grid,mapwidth,mapheight,closed_list,current_node,goal,open_list):
    next_pos=[(0,1),(1,0),(-1,0),(0,-1),(1,1),(-1,1),(1,-1),(-1,-1)]
    out_node=[]
    new_nodes=[]
    flag1=0
    flag2=0
    node_pos=[(0,0),(0,0),(0,0),(0,0),(0,0),(0,0),(0,0),(0,0)]
    for new_pos in range(len(next_pos)):
        node_pos[new_pos]=(node[0]+next_pos[new_pos][0],node[1]+next_pos[new_pos][1])
        hues=heuristic(node_pos[new_pos],current_node,goal)
        new_node=(node_pos[new_pos][0],node_pos[new_pos][1],node[0],node[1],hues[1],hues[0])
        flag2=0
        
        if new_node not in closed_list:
            if new_node not in open_list:
               if node_pos[new_pos][0]>=0 and node_pos[new_pos][1]>=0 and node_pos[new_pos][0]<mapwidth and node_pos[new_pos][1]<mapheight:
                  if map_grid[node_pos[new_pos][1]][node_pos[new_pos][0]] != 0:
                     out_node.append(new_node)
    return out_node     

def heuristic(kid,current_node,goal):
    g=current_node[5]+1
    f=abs(kid[0]-goal[0])+abs(kid[1]-goal[1])
    #dx=abs(kid[0]-goal[0])
    #dy=abs(kid[1]-goal[1])
    D=1
    D2=1
    h=g+f
    #h=(D*(dx + dy)) + ((D2 -(2*D)) * min(dx, dy))
    h_score=[g,h]
    return h_score

def rectIntersect(p1,p2,i,j,tilesizew,tilesizeh):
    r1 = (i+tilesizew/2, j+tilesizeh/2)
    r2 = (i-tilesizew/2, j-tilesizeh/2)
    r3 = (i-tilesizew/2, j+tilesizeh/2)
    r4 = (i+tilesizew/2, j-tilesizeh/2)
    if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
        #if this is true there has to be 1 more check
        if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
            return True
    return False

def lineIntersect(p1,p2,tilemap,tilesizew,tilesizeh):
    i=0
    while i<len(tilemap):
        j=0
        while j<len(tilemap[i]):
            if tilemap[i][j] == 0 and rectIntersect(p1,p2,i,j,tilesizew,tilesizeh):
                return True
            j=j+1
        i=i+1
    return False

def optimisePath(path,tilemap,tilesizew,tilesizeh):
    #1st and last point cant change
    optimised = True       
    while optimised == True:
        i=len(path)-1
        optimised = False
        print("optimising " + str(len(path)))            
        while i>1: #at least index i equal to 2 (3 needed for triangulation)
            print("not reached start node, trying to optimise")
            while i>1 and lineIntersect(path[i],path[i-2],tilemap,tilesizew,tilesizeh) == False: 
                print("can optimise here")
                path.pop(i-1)
                i = i-1 #new position of i
                #print('i = ' + str(i))
                optimised = True #is setting again and again using too much memory?
            i=i-1
    #making nongoal points better
    if len(path)>2:
        #0th and last index never part of it
        numiter = 5
        #mindiff = 0.05
        index=1
        while index<len(path)-1:
            print("optimising non goal points")
            min1 = 0.0
            max1 = 1.0
            min2 = 0.0
            max2 = 1.0 #we prob don't need all, can initiate again after this loop
            for k in range(numiter):
                if min1==max1:
                    print("best found")
                    break
                r = round(random.uniform(min1, max1),3)
                newPoint = int((1-r)*path[index-1][0]+r*path[index][0]) , int((1-r)*path[index-1][1]+r*path[index][1])
                if lineIntersect(newPoint, path[index+1], tilemap,tilesizew,tilesizeh) == True:
                    #if r<max1: #always true, that's where we found r
                    min1 = r                   
                elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                    print("line 1 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                    path[index] = newPoint                  
                    max1 = r
            for k in range(numiter):
                if min2==max2:
                    print("best found")
                    break
                r = round(random.uniform(min2, max2),3)
                newPoint = int((1-r)*path[index+1][0]+r*path[index][0]) , int((1-r)*path[index+1][1]+r*path[index][1])
                if lineIntersect(newPoint, path[index-1], tilemap,tilesizew,tilesizeh) == True:
                    #if r<max1: #always true, that's where we found r
                    min2 = r
                elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                    print("line 2 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                    path[index] = newPoint                  
                    max2 = r
            index = index+1
    
        
def world():
#colour
    white=(255 ,255 ,255 )
    black=(0, 0, 0)
#resources
    obst=0
    free=1
    pug=2
    #dictionary
    textures={
              obst : pygame.image.load('borderb.png'),
              free : pygame.image.load('border.png'),
              pug  : pygame.image.load('pugmark.png')
             }
    tilesizew=20
    tilesizeh=20
    mapwidth=20
    mapheight=20
    tilemap=np.zeros((20,20))
    start=(1,5)
    goal=(10,17)
    for row in range(mapheight):
        for column in range(mapwidth):
            tilemap[row][column]=1
    tilemap[4][10]=0
    tilemap[4][11]=0
    tilemap[5][11]=0
    tilemap[6][11]=0
    tilemap[7][11]=0
    tilemap[7][15]=0
    tilemap[8][15]=0
    tilemap[9][15]=0
    tilemap[10][15]=0
    tilemap[6][15]=0
    path=astar(tilemap,start,goal,mapwidth,mapheight)
    optimisePath(path,tilemap,tilesizew,tilesizeh)
    
    for step in path:
        tilemap[step[1]][step[0]]=2
   
    print ("Path:")
    print (path)
    dronepos = [goal[0],goal[1]]

    pygame.init()
    DISPLAYSURF=pygame.display.set_mode((mapwidth*tilesizew,mapheight*tilesizeh))

    
    while True:
          for event in pygame.event.get():
              if event.type== QUIT:
                 pygame.quit()
                 sys.exit()
          
          for row in range(mapheight):
              for column in range(mapwidth):
             #pygame.draw.rect(DISPLAYSURF, textures[tilemap[row][column]],(column*tilesize,row*tilesize,tilesize,tilesize))
                  DISPLAYSURF.blit(textures[tilemap[row][column]],(column*tilesizew,row*tilesizeh))
          #DISPLAYSURF.blit(drone,(dronepos[0]*tilesizew,dronepos[1]*tilesizeh))
          pygame.draw.circle(DISPLAYSURF, black, (dronepos[0]*tilesizew,dronepos[1]*tilesizeh), 5)
          pygame.display.update()
if __name__ == '__main__':
    world()
