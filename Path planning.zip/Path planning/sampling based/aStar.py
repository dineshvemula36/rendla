import sys
import minHeap
from pygame import *

white = 255, 255, 255
dark_green = 0, 102, 0

def dist(p1,p2):    #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def lineIntersect(p1,p2):
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<0:
            return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False

def isPresent(arr, obj):
    for a in arr:
        if a == obj:
            return True
    return False

def isPresentEdge(arr, v1, v2):
    for a in arr:
        if (a.node1 == v1.node and a.node2 == v2.node) or (a.node2 == v1.node and a.node1 == v2.node):
            return a
    return None

class Edge:
    def __init__(self, node1, node2):
        self.node1 = node1
        self.node2 = node2
        self.length = dist(node1.point,node2.point)
        
class PossibleEdges:
    def __init__(self, nodes):
        self.edges = []
        i=0
        while i<len(nodes):
            j=i+1
            while j<len(nodes):
                if lineIntersect(nodes[i].point,nodes[j].point) == False:
                    self.edges.append(Edge(nodes[i],nodes[j]))
                j=j+1
            i=i+1
                    

class Vertex:   
    def __init__(self, node, startNode, finalNode):
        self.node = node
        self.heuristicValue = dist(node.point, finalNode.point)
        self.pathLengthSoFar = 0
        if node == startNode:           
            self.data = 0.0
        else:
            self.data = sys.float_info.max
        #parent? - already there in node

class AStar:
    def __init__(self, nodes, edges, startNode, finalNode):
        self.vertices = []
        for node in nodes:
            self.vertices.append(Vertex(node,startNode,finalNode))
        #self.nodes = nodes
        self.edges = edges
        self.pQueue = minHeap.MinHeap()
        for vertex in self.vertices:
            self.pQueue.add(vertex)
                        

    def findAdjacentNotSeen(self,v,popped): #popped is an array
        adjacent = []
        for vertex in self.vertices:
            if isPresent(popped,vertex) == False and isPresentEdge(self.edges,vertex,v) != None:
                adjacent.append(vertex)
        return adjacent
    

    def findShortestDist(self, screen, seen):
            while self.pQueue.size != 0:
                current = self.pQueue.pop()
                seen.append(current)
                adjacent = self.findAdjacentNotSeen(current,seen);
                for vertex in adjacent:
                    e = isPresentEdge(self.edges,vertex.node,current.node)
                    if vertex.data>e.length + current.pathLengthSoFar + vertex.heuristicValue:
                        if vertex.node.parent != None:
                            pygame.draw.line(screen,white,vertex.node.parent.point,vertex.node.point)
                        vertex.node.parent = current.node
                        pygame.draw.line(screen,dark_green,vertex.node.parent.point,vertex.node.point)
                        vertex.pathLengthSoFar = e.length + current.pathLengthSoFar
                        vertex.node.srcdist = vertex.pathLengthSoFar
                        vertex.data = vertex.pathLengthSoFar + vertex.heuristicValue
                        i=0
                        while i<self.pQueue.size:
                            if self.pQueue.items[i] == vertex:
                                self.pQueue.heapifyUp(i)
                                break
                            else:
                                i = i+1