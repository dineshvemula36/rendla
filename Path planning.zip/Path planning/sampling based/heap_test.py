import math

class MinHeap:
#min heapfor aStar
    def __init__(self):
        self.items = []
        self.size = 0
        
    def peek(self):
        return self.items[0]
    
    def pop(self): 
        min = self.items[0]
        self.items[0] = self.items[self.size-1]
        self.size = self.size-1
        self.heapifyDown()
        return min;
    
    def add(self, a):
        self.items.append(a)
        self.size = self.size+1
        self.heapifyUp(self.size-1);
    
    def heapifyDown(self):
        if self.size < 2:
                return;
        else:
            i = 0;
            while i*2+1<self.size:
                smallerChildIndex = 2*i+1;
                if 2*i+2 < self.size and self.items[2*i+1]>self.items[2*i+2]:
                    smallerChildIndex = 2*i+2;
                if self.items[i] > self.items[smallerChildIndex]:
                    temp = self.items[i]
                    self.items[i] = self.items[smallerChildIndex]
                    self.items[smallerChildIndex] = temp
                    i = smallerChildIndex
                else:
                    break
    
    def heapifyUp(self, index):
            if self.size<2:
                return;
            else:
                i = index;
                while math.floor((i-1)/2)>=0:
                    if i%2 == 0 and i!=0 and self.items[i] >= self.items[i-1]:
                        break;
                    if self.items[i] >= self.items[math.floor((i-1)/2)]:
                        break;
                    else:
                        if i!=0 and self.items[i] < self.items[math.floor((i-1)/2)]:
                            temp = self.items[i]
                            self.items[i] = self.items[math.floor((i-1)/2)]
                            self.items[math.floor((i-1)/2)] = temp
                            i = math.floor((i-1)/2)
    

def main():
    min_heap = MinHeap()
    min_heap.add(2)
    min_heap.add(9)
    min_heap.add(0)
    while min_heap.size > 0:
        print(min_heap.peek())
        print(min_heap.pop())
    
if __name__ == '__main__':
    main()