import math, sys, pygame, random
import maxHeap
from math import *
from pygame import *
import time

class Node(object):
    def __init__(self, point, parent):
        super(Node, self).__init__()
        self.point = point
        self.parent = parent
        self.srcdist = 0
        self.inBeacons = False

k_nearest = 3
max_heap = maxHeap.MaxHeap()
XDIM = 720
YDIM = 500
windowSize = [XDIM, YDIM]
delta = 25.0
GAME_LEVEL = 4
SAMPLE_RADIUS = 3
BEACON_RADIUS = 6
GOAL_RADIUS = 10
MIN_DISTANCE_TO_ADD = 1.0
NUMNODES = 3000
pygame.init()
fpsClock = pygame.time.Clock()
screen = pygame.display.set_mode(windowSize)
white = 255, 255, 255
black = 0, 0, 0
red = 255, 0, 0
green = 0, 255, 0
blue = 0, 0, 255
cyan = 0,180,105
gray = 150,150,150
dark_green = 0, 102, 0
biasingRatio = 100
intelSampleFreq = 5 #after every 5 normal samples
optimiseIter = 200
minImrovement = 0.0005 #0.05%

count = 0
rectObs = []
circleObs = []

def dist(p1,p2):     #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def point_circle_collision(p1, p2, radius):
    distance = dist(p1,p2)
    if (distance <= radius):
        return True
    return False

def step_from_to(p1,p2):
    if dist(p1,p2) < delta:
        return None
    elif collides(p2) == False and lineIntersect(p1,p2) == False:
        return p2
    else:
        i = floor(dist(p1,p2)/delta)
        theta = atan2(p2[1]-p1[1],p2[0]-p1[0])
        while i>0:
            p = p1[0] + i*delta*cos(theta), p1[1] + i*delta*sin(theta)
            if collides(p) == False and lineIntersect(p1,p) == False:
                return p
            else:
                i = i-1       
        return None

def collides(p):    #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False


def get_random_clear():
    #while True:
    p = int(random.random()*XDIM), int(random.random()*YDIM)
        #noCollision = collides(p)
        #if noCollision == False:
    return p

def get_random_intelligent(node,radius):
    #while True:
    p = int(node.point[0] + random.random()*radius), int(node.point[1] + random.random()*radius)
        #noCollision = collides(p)
        #if noCollision == False:
    return p

def init_obstacles(configNum):  #initialized the obstacle
    global rectObs
    global circleObs
    rectObs = []
    #print("config "+ str(configNum))
    if (configNum == 0):
        rectObs.append(pygame.Rect((XDIM / 2.0 - 50, YDIM / 2.0 - 100),(100,200)))
    if (configNum == 1):
        rectObs.append(pygame.Rect((100,50),(200,150)))
        rectObs.append(pygame.Rect((400,200),(200,100)))
    if (configNum == 2):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 3):
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 4):
        circleObs.append([200,100,100]) 
        circleObs.append([370,300,80])
    if (configNum == 5):
        circleObs.append([370,300,80]) 
        rectObs.append(pygame.Rect((100,50),(200,150)))
    if (configNum == 6):
        rectObs.append(pygame.Rect((247,25),(100,450)))
        rectObs.append(pygame.Rect((373,25),(100,450)))
    if configNum == 7:
        rectObs.append(pygame.Rect((100,200),(50,200)))
        rectObs.append(pygame.Rect((150,200),(100,75)))
        rectObs.append(pygame.Rect((250,200),(50,200)))
        rectObs.append(pygame.Rect((150,325),(40,75)))
        rectObs.append(pygame.Rect((210,325),(40,75)))
        rectObs.append(pygame.Rect((595,25),(100,450)))

    for rect in rectObs:
        pygame.draw.rect(screen, gray, rect)
    for circle in circleObs:
        pygame.draw.circle(screen, gray, (circle[0],circle[1]), circle[2])


def lineIntersect(p1,p2):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False
        
#def addBoundaryPoints(arr):
#    for rect in rectObs:
#        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
#        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
#        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
#        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
#        arr.append(Node(r1,None))
#        arr.append(Node(r2,None))
#        arr.append(Node(r3,None))
#        arr.append(Node(r4,None))
#    for circle in circleObs:
#        c1 = (circle[0], circle[1]+circle[2])
#        c2 = (circle[0], circle[1]-circle[2])
#        c3 = (circle[0]+circle[2], circle[1])
#        c4 = (circle[0]-circle[2], circle[1])
#        arr.append(Node(c1,None))
#        arr.append(Node(c2,None))
#        arr.append(Node(c3,None))
#        arr.append(Node(c4,None))

def reset():
    global count
    screen.fill(white)
    init_obstacles(GAME_LEVEL)
    count = 0
    
def minArray(arr):
    min = arr[0]
    for a in arr:
        if min.srcdist>a.srcdist:
            min=a
    return min

def buildTree(nodes,beacons,sample,index,radius):    
    foundNext = False
    rand = None
    while foundNext == False:
        if sample < intelSampleFreq:
            rand = get_random_clear()
            pygame.draw.circle(screen, black, rand, SAMPLE_RADIUS)
        else:
            rand = get_random_intelligent(beacons[index],radius)
            pygame.draw.circle(screen, cyan, rand, SAMPLE_RADIUS)
            print("intelligent sampling this time")            
        for p in nodes:
            newPoint = step_from_to(p.point,rand)
            if newPoint != None:
                if max_heap.size < k_nearest:                                                   
                    max_heap.add(maxHeap.HeapItem(p,dist(p.point,rand)))
                    foundNext = True
                elif dist(p.point,rand) < max_heap.peek().data:
                    max_heap.pop()
                    max_heap.add(maxHeap.HeapItem(p,dist(p.point,rand)))
                    foundNext = True
    newPointFind = []
    for item in max_heap.items:
        newnode = Node(step_from_to(item.node.point,rand),item.node)
        newnode.srcdist = item.node.srcdist + dist(item.node.point, newnode.point)
        newPointFind.append(newnode)        
    min = minArray(newPointFind)
    #check heap
    nodes.append(min)
    pygame.draw.line(screen,dark_green,min.parent.point,min.point)              
    
    #rewire:
#    arr= []
    arr = [min]
    while max_heap.size>0:
        arr.append(max_heap.pop().node)

    if (len(arr)>2):
        i=0
        while i<len(arr):
            j=0
            rewired = False
            while j<len(arr):
                if i!=j and arr[i].parent!=arr[j] and arr[j].parent!=arr[i] and lineIntersect(arr[i].point, arr[j].point)==False:
                    if arr[i].srcdist>arr[j].srcdist+dist(arr[i].point,arr[j].point):
                          pygame.draw.line(screen,white,arr[i].parent.point,arr[i].point)
                          arr[i].parent = arr[j]
                          arr[i].srcdist = arr[j].srcdist+dist(arr[i].point,arr[j].point)
                          pygame.draw.line(screen,dark_green,arr[j].point,arr[i].point)
                          rewired = True                               
                    elif arr[j].srcdist>arr[i].srcdist+dist(arr[i].point,arr[j].point):
                          pygame.draw.line(screen,white,arr[j].parent.point,arr[j].point)
                          arr[j].parent = arr[i]
                          arr[j].srcdist = arr[i].srcdist+dist(arr[i].point,arr[j].point)
                          pygame.draw.line(screen,dark_green,arr[i].point,arr[j].point)
                          rewired = True
                j=j+1
            if (i == len(arr)-1 and rewired == True):
                i=0 
            else:
                i=i+1
                
    changed = True
    while changed == True:
        changed = False
        for n in nodes:
            if n.parent != None:
                old = n.srcdist
                n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                if n.srcdist!=old:
                    changed = True
                
#    if (len(arr)>1):
#        i=0
#        while i<len(arr):
#           # rewired = False
#            if arr[i].parent!=min and min.parent!=arr[i] and lineIntersect(arr[i].point, min.point)==False:
#                if arr[i].srcdist>min.srcdist+dist(arr[i].point,min.point):
#                      pygame.draw.line(screen,white,arr[i].parent.point,arr[i].point)
#                      arr[i].parent = min
#                      arr[i].srcdist = min.srcdist+dist(arr[i].point,min.point)
#                      pygame.draw.line(screen,dark_green,min.point,arr[i].point)
#                  #    rewired = True  
#            i = i+1

    return nodes

def main():
    global count
    
    initPoseSet = False
    initialPoint = Node(None, None)
    goalPoseSet = False
    goalPoint = Node(None, None)
    reachedGoal = Node(None, None)
    currentState = 'init'
    reset()
    nodes1 = []
    nodes2 = []
    beacons = []
    initialPathFound = False
    newPath = False
    index=0
    sample=0

    while True:
        screen.fill(white)
        init_obstacles(GAME_LEVEL)
        if initPoseSet == True:
            pygame.draw.circle(screen, red, initialPoint.point, GOAL_RADIUS)
        if goalPoseSet == True:
            pygame.draw.circle(screen, blue, goalPoint.point, GOAL_RADIUS)
        for n in nodes1:
            if n.parent!=None:                   
                pygame.draw.line(screen,dark_green,n.point,n.parent.point)
        for n in nodes2:
            if n.parent!=None:                   
                pygame.draw.line(screen,dark_green,n.point,n.parent.point)
        for b in beacons:
            pygame.draw.circle(screen, green, b.point, BEACON_RADIUS)
        if currentState == 'goalFound':
            currNode = reachedGoal
            while currNode.parent != None:
                pygame.draw.line(screen,red,currNode.point,currNode.parent.point)
                currNode = currNode.parent
            time.sleep(0.1)
        time.sleep(0.01)
        if currentState == 'init':
            print('goal point not yet set')
            pygame.display.set_caption('Select Starting Point and then Goal Point')
            fpsClock.tick(10)
        elif currentState == 'goalFound':
            global optimiseIter
            if optimiseIter>0:
                currNode = reachedGoal
                oldGoal = None
                pygame.display.set_caption('Goal Reached, dist = ' + str(reachedGoal.srcdist))
                print ("Path found")
                print (len(nodes1))
                while currNode.parent != None:
                    pygame.draw.line(screen,red,currNode.point,currNode.parent.point)
                    currNode = currNode.parent
                time.sleep(0.1)
                if initialPathFound == True:
                    time.sleep(2)
                    initialPathFound = False
                
                #rrt_star_smart step            
                optimised = True
                count = count+1
                if count<NUMNODES:
                    print("continue optimising then building tree")
                    if newPath == True:
                        while optimised == True:
                            print("optimising")
                            optimised = False
                            startNode = reachedGoal
                            startParentNode = reachedGoal.parent
                            while startParentNode != None and startParentNode.parent != None:
                                print("not reached start node, trying to optimise")
                                if lineIntersect(startNode.point,startParentNode.parent.point) == False:
                                    print("can optimise here")
                                    startNode.parent = startParentNode.parent
                                    startNode.srcdist = startNode.parent.srcdist + dist(startNode.point,startNode.parent.point)
                                    pygame.draw.line(screen,white,startNode.point,startParentNode.point)
                                    pygame.draw.line(screen,white,startParentNode.point,startNode.parent.point)
                                    pygame.draw.line(screen,red,startNode.point,startNode.parent.point)
                                    if startParentNode in beacons:
                                        beacons.remove(startParentNode)
                                    nodes1.remove(startParentNode)
                                    time.sleep(0.2)
                                    if startNode != reachedGoal and startNode.inBeacons == False:
                                        print("adding startnode to beacons")
                                        beacons.append(startNode)
                                        startNode.inBeacons = True
                                        pygame.draw.circle(screen, green, startNode.point, BEACON_RADIUS)
                                    if startNode.parent != initialPoint and startNode.parent.inBeacons == False:
                                        print("adding new startnode parent to beacons")
                                        beacons.append(startNode.parent)
                                        startNode.parent.inBeacons = True
                                        pygame.draw.circle(screen, green, startNode.parent.point, BEACON_RADIUS)
                                    optimised = True
                                
                                startNode = startNode.parent
                                startParentNode = startNode.parent #new start node
                                print("set new startnode and parent")
                                time.sleep(0.2)
                            newPath = False
                    
                    changed = True
                    while changed == True:
                        changed = False
                        for n in nodes1:
                            if n.parent != None:
                                old = n.srcdist
                                n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                if n.srcdist!=old:
                                    changed = True                           
                    pygame.display.set_caption('Goal Reached, dist = ' + str(reachedGoal.srcdist))
                    #rBeacon = biasingRatio*(len(nodes)/(len(nodes) - len(beacons))) #can also be a fixed number
                    rBeacon = biasingRatio
                    if len(beacons)>0:
                        nodes1 = buildTree(nodes1,beacons,sample,index,rBeacon)
                        if sample<intelSampleFreq:    
                            sample= sample+1
                        else:
                            print("1 intelligent sampling done, going to normal again")
                            sample = 0
                            if index < len(beacons)-1:
                                index = index+1
                            else:
                                index = 0
                                print("all beacons checked, starting again")
                    else:
                        nodes1 = buildTree(nodes1,beacons,0,0,0)                    
                                           
                    newNode = nodes1[len(nodes1)-1]    
                    if point_circle_collision(newNode.point, goalPoint.point, GOAL_RADIUS):
                        currentState = 'goalFound'
                        if reachedGoal.srcdist >= newNode.srcdist:
                            newPath = True
                            oldGoal = reachedGoal
                            while oldGoal.parent != None:
                                pygame.draw.line(screen,dark_green,oldGoal.point,oldGoal.parent.point)
                                oldGoal = oldGoal.parent
                            time.sleep(0.2)
                            reachedGoal = newNode
                            currNode = reachedGoal
                            while currNode.parent != None:
                                pygame.draw.line(screen,red,currNode.point,currNode.parent.point)
                                currNode = currNode.parent
                            time.sleep(0.2)
                            optimised = True            
                optimizePhase = True
                global minImprovement
                if oldGoal != None and (oldGoal.srcdist-reachedGoal.srcdist)/oldGoal.srcdist>=minImprovement:
                    optimiseIter = 0
                else:
                    optimiseIter = optimiseIter-1
            else:
                pygame.display.set_caption('No further improvement, dist = ' + str(reachedGoal.srcdist))
        
        elif currentState == 'optimize':
            fpsClock.tick(0.5)
            pass
        elif currentState == 'buildTree':
            global max_heap
            count = count+1
            pygame.display.set_caption('Performing RRT* Smart connect')
            if count < NUMNODES:
                nodes1 = buildTree(nodes1,beacons,0,0,0)
                newnode = nodes1[len(nodes1)-1]
                parentNode = None
                for p in nodes2:
                    if lineIntersect(newnode.point,p.point) == False:
                        if parentNode == None:
                            parentNode = p 
                        elif dist(p.point,newnode.point) <= dist(parentNode.point,newnode.point):
                            parentNode = p                      
                if parentNode != None:
                     pygame.draw.line(screen,dark_green,parentNode.point,newnode.point)                    
                     currNode = parentNode
                     currNodeParent = parentNode.parent
                     parentNode.parent = newnode
                     parentNode.srcdist = newnode.srcdist + dist(parentNode.point,newnode.point)                     
                     while currNodeParent!=None:
                         temp = currNodeParent.parent
                         currNodeParent.parent = currNode
                         currNodeParent.srcdist = currNodeParent.parent.srcdist + dist(currNodeParent.point,currNodeParent.parent.point)
                         currNode = currNodeParent
                         currNodeParent = temp
                    
                     changed = True
                     while changed == True:
                        changed = False
                        for n in nodes2:
                            if n.parent != None:
                                old = n.srcdist
                                n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                if n.srcdist!=old:
                                    changed = True
                                             
                     for n in nodes2:
                        nodes1.append(n)
                     for p in nodes1:
                         if p!= newnode:
                             newPoint = step_from_to(p.point,newnode.point)
                             if newPoint != None:
                                 if max_heap.size < k_nearest:                                                   
                                     max_heap.add(maxHeap.HeapItem(p,dist(p.point,newnode.point)))
                                 elif dist(p.point,newnode.point) < max_heap.peek().data:
                                     max_heap.pop()
                                     max_heap.add(maxHeap.HeapItem(p,dist(p.point,newnode.point)))
                                 
                         arr = [newnode]
                         while max_heap.size>0:
                            arr.append(max_heap.pop().node)
                    
                         if (len(arr)>2):
                            i=0
                            while i<len(arr):
                                j=0
                                rewired = False
                                while j<len(arr):
                                    if i!=j and arr[i].parent!=arr[j] and arr[j].parent!=arr[i] and lineIntersect(arr[i].point, arr[j].point)==False:
                                        if arr[i].srcdist>arr[j].srcdist+dist(arr[i].point,arr[j].point):
                                              pygame.draw.line(screen,white,arr[i].parent.point,arr[i].point)
                                              arr[i].parent = arr[j]
                                              arr[i].srcdist = arr[j].srcdist+dist(arr[i].point,arr[j].point)
                                              pygame.draw.line(screen,dark_green,arr[j].point,arr[i].point)
                                              rewired = True                               
                                        elif arr[j].srcdist>arr[i].srcdist+dist(arr[i].point,arr[j].point):
                                              pygame.draw.line(screen,white,arr[j].parent.point,arr[j].point)
                                              arr[j].parent = arr[i]
                                              arr[j].srcdist = arr[i].srcdist+dist(arr[i].point,arr[j].point)
                                              pygame.draw.line(screen,dark_green,arr[i].point,arr[j].point)
                                              rewired = True
                                    j=j+1
                                if (i == len(arr)-1 and rewired == True):
                                    i=0 
                                else:
                                    i=i+1
                                    
                         changed = True
                         while changed == True:
                            changed = False
                            for n in nodes1:
                                if n.parent != None:
                                    old = n.srcdist
                                    n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                    if n.srcdist!=old:
                                        changed = True
                        
                     currentState = 'goalFound'
                     reachedGoal = goalPoint
                     newPath = True
                
                else:
                   count = count+1 
                   if count < NUMNODES:
                        nodes2 = buildTree(nodes2,beacons,0,0,0)
                        newnode = nodes2[len(nodes2)-1]
                        parentNode = None
                        for p in nodes1:
                            if lineIntersect(newnode.point,p.point) == False:
                                if parentNode == None:
                                    parentNode = p 
                                elif dist(p.point,newnode.point) <= dist(parentNode.point,newnode.point):
                                    parentNode = p 
                        if parentNode != None:
                             pygame.draw.line(screen,dark_green,parentNode.point,newnode.point)                    
                             currNode = newnode
                             currNodeParent = newnode.parent
                             newnode.parent = parentNode
                             newnode.srcdist = parentNode.srcdist + dist(parentNode.point,newnode.point)                     
                             while currNodeParent!=None:
                                 temp = currNodeParent.parent
                                 currNodeParent.parent = currNode
                                 currNodeParent.srcdist = currNodeParent.parent.srcdist + dist(currNodeParent.point,currNodeParent.parent.point)
                                 currNode = currNodeParent
                                 currNodeParent = temp
                             
                             changed = True
                             while changed == True:
                                changed = False
                                for n in nodes2:
                                    if n.parent != None:
                                        old = n.srcdist
                                        n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                        if n.srcdist!=old:
                                            changed = True
                             
                             for n in nodes2:
                                nodes1.append(n)
                             for p in nodes1:
                                 if p!= newnode:
                                     newPoint = step_from_to(p.point,newnode.point)
                                     if newPoint != None:
                                         if max_heap.size < k_nearest:                                                   
                                             max_heap.add(maxHeap.HeapItem(p,dist(p.point,newnode.point)))
                                         elif dist(p.point,newnode.point) < max_heap.peek().data:
                                             max_heap.pop()
                                             max_heap.add(maxHeap.HeapItem(p,dist(p.point,newnode.point)))
                                 
                             arr = [newnode]
                             while max_heap.size>0:
                                arr.append(max_heap.pop().node)
                        
                             if (len(arr)>2):
                                i=0
                                while i<len(arr):
                                    j=0
                                    rewired = False
                                    while j<len(arr):
                                        if i!=j and arr[i].parent!=arr[j] and arr[j].parent!=arr[i] and lineIntersect(arr[i].point, arr[j].point)==False:
                                            if arr[i].srcdist>arr[j].srcdist+dist(arr[i].point,arr[j].point):
                                                  pygame.draw.line(screen,white,arr[i].parent.point,arr[i].point)
                                                  arr[i].parent = arr[j]
                                                  arr[i].srcdist = arr[j].srcdist+dist(arr[i].point,arr[j].point)
                                                  pygame.draw.line(screen,dark_green,arr[j].point,arr[i].point)
                                                  rewired = True                               
                                            elif arr[j].srcdist>arr[i].srcdist+dist(arr[i].point,arr[j].point):
                                                  pygame.draw.line(screen,white,arr[j].parent.point,arr[j].point)
                                                  arr[j].parent = arr[i]
                                                  arr[j].srcdist = arr[i].srcdist+dist(arr[i].point,arr[j].point)
                                                  pygame.draw.line(screen,dark_green,arr[i].point,arr[j].point)
                                                  rewired = True
                                        j=j+1
                                    if (i == len(arr)-1 and rewired == True):
                                        i=0 
                                    else:
                                        i=i+1
                                        
                             changed = True
                             while changed == True:
                                changed = False
                                for n in nodes1:
                                    if n.parent != None:
                                        old = n.srcdist
                                        n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                        if n.srcdist!=old:
                                            changed = True
                                        
                             currentState = 'goalFound'
                             reachedGoal = goalPoint
                             newPath = True
              
            else:
                print("Ran out of nodes... :(")
                return;

        #handle events
        for e in pygame.event.get():
            if e.type == QUIT or (e.type == KEYUP and e.key == K_ESCAPE):
                sys.exit("Exiting")
            if e.type == MOUSEBUTTONDOWN:
                print('mouse down')
                if currentState == 'init':
                    if initPoseSet == False:
                        nodes1 = []
                        if collides(e.pos) == False:
                            print('initiale point set: '+str(e.pos))
                            initialPoint = Node(e.pos, None)
                            nodes1.append(initialPoint)
                            initPoseSet = True
                            pygame.draw.circle(screen, red, initialPoint.point, GOAL_RADIUS)
                    elif goalPoseSet == False:
                        print('goal point set: '+str(e.pos))
                        if collides(e.pos) == False:
                            nodes2 = []
                            goalPoint = Node(e.pos,None)
                            nodes2.append(goalPoint)
                            goalPoseSet = True
                            pygame.draw.circle(screen, blue, goalPoint.point, GOAL_RADIUS)
                            currentState = 'buildTree'
                else:
                    currentState = 'init'
                    initPoseSet = False
                    goalPoseSet = False
                    reset()

        pygame.display.update()
        fpsClock.tick(10000)


#continue optimising only if considerable change after 200-500 iterations maybe - in rrt,rrt* too
#presentation - title bar, also multiple drawing??
#structure of code - if, while statements
#intelligent sample point in green, even beacons in green

if __name__ == '__main__':
    main()