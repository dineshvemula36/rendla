import random
from math import *
import geometry

class Node(object):
    def __init__(self, point, parent):
        super(Node, self).__init__()
        self.point = point
        self.parent = parent
        self.srcdist = 0

delta = 25.0
GOAL_RADIUS = 10
MIN_DISTANCE_TO_ADD = 1.0
#NUMNODES = 100
minImprovement = 0.0005 #0.05%

def dist(p1,p2):    #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def point_circle_collision(p1, p2, radius):
    if dist(p1,p2) <= radius:
        return True
    return False

def collides(p,rectObs,circleObs): #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def lineIntersect(p1,p2,rectObs,circleObs):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False

def boundary(p,width,height):
    #print('boundary checking ' + str(p[0]) + ' ' + str(p[1]))
    if p[0]<=0 or p[0]>=width or p[1]<=0 or p[1]>=height:
        return True
    else:
        return False
    
def get_random_clear(width,height,rectObs,circleObs):
    #while True:
    p = int(random.random()*width), int(random.random()*height)
    while collides(p,rectObs,circleObs) == True or boundary(p,width,height) == True:
        p = int(random.random()*width), int(random.random()*height)
    return p
    
def step_from_to(p1,p2,rectObs,circleObs):
    #if dist(p1,p2) < delta:
    #    return None
    if lineIntersect(p1,p2,rectObs,circleObs) == False:
        return p2
    else:
        i = floor(dist(p1,p2)/delta)
        theta = atan2(p2[1]-p1[1],p2[0]-p1[0])
        while i>0:
            p = p1[0] + i*delta*cos(theta), p1[1] + i*delta*sin(theta)
            if collides(p,rectObs,circleObs) == False and lineIntersect(p1,p,rectObs,circleObs) == False:
                return p
            else:
                i = i-1       
        return None

def buildTree(group,width,height,rectObs,circleObs): #inputting group instead of nodes
    foundNext = False
    newNode = None
    allVert = {}
#    noVert = {}
    #print('a')
    while foundNext == False:
        #print('b')
        rand = get_random_clear(width,height,rectObs,circleObs)
        for v in group:
            parentNode = None
            #vfound = False
            for p in group[v]:
                #print('c')
                newPoint = step_from_to(p.point,rand,rectObs,circleObs)
                if newPoint != None:
                    if parentNode == None:
                        #print('d')
                        parentNode = p
                        foundNext = True
                        #vfound = True
                        #allVert[v] = True
                    elif dist(p.point,rand) < dist(parentNode.point,rand):  
                        #print('e')
                        parentNode = p
                        foundNext = True
                        #vfound = True                
#            if vfound == False:
#                noVert[v.vId] = True    
            #print('f')
            if parentNode != None:
                allVert[v] = True
                newpoint = step_from_to(parentNode.point,rand,rectObs,circleObs)
                newNode = Node(newpoint, parentNode)
                newNode.srcdist = parentNode.srcdist + dist(newNode.point,parentNode.point)
                group[v].append(newNode)
    return [newNode,allVert]

def optimisePath(path,rectObs,circleObs):
    optimised = True       
    while optimised == True:
        i=len(path)-2
        optimised = False
        print("optimising " + str(len(path)))            
        while i>1: #at least index i equal to 2 (3 needed for triangulation)
            #print("not reached start node, trying to optimise")
            while i>1 and lineIntersect(path[i],path[i-2],rectObs,circleObs) == False:
                #print("can optimise here")
                path.pop(i-1)
                i = i-1 #new position of i
                #print('i = ' + str(i))
                optimised = True #is setting again and again using too much memory?
            i=i-1
            
    #finding btr non goal points
    numiter = 5
    #mindiff = 0.05
    index=1
    while index<len(path)-1:
        min1 = 0.0
        max1 = 1.0
        min2 = 0.0
        max2 = 1.0 #we prob don't need all, can initiate again after this loop
        for k in range(numiter):
            if min1==max1:
                break
            r = round(random.uniform(min1, max1),3)
            newPoint = int((1-r)*path[index-1][0]+r*path[index][0]) , int((1-r)*path[index-1][1]+r*path[index][1])
            if lineIntersect(newPoint, path[index+1], rectObs, circleObs) == True:
                #if r<max1: #always true, that's where we found r
                min1 = r                   
            elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                print("line 1 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                path[index] = newPoint                  
                max1 = r
        for k in range(numiter):
            if min2==max2:
                break
            r = round(random.uniform(min2, max2),3)
            newPoint = int((1-r)*path[index+1][0]+r*path[index][0]) , int((1-r)*path[index+1][1]+r*path[index][1])
            if lineIntersect(newPoint, path[index-1], rectObs, circleObs) == True:
                #if r<max1: #always true, that's where we found r
                min2 = r
            elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                print("line 2 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                path[index] = newPoint
                max2 = r
        index = index+1

def optimiseFoundPaths(newpoint,allEdges,rectObs,circleObs):
    #try to see if better path thru new point
    #start from beginning and see where this can fit, once u find one in the beginning try to find end one where it will fit, then optimisepath and see if it is btr
    for edgekey in allEdges:
        print('optimising found paths ' + edgekey)
        #if edgekey not in checkedEdges:
        #splitstr = edgekey.split('-')
        #if int(splitstr[0]) in verts or int(splitstr[1]) in verts: #is this necessary? can we add this to others also? - but in that case would have been added to the tree...but we are not checking all only checking group
        #splitstr = edgekey.split('-')
        #if int(splitstr[0]) not in checkedEdges or int(splitstr[1]) not in checkedEdges: #these trees were not able to add - but the other one may be able to
        path = allEdges[edgekey].linkPoints
        newpath = []
        i=0
        while i<len(path) and lineIntersect(newpoint,path[i],rectObs,circleObs) == True:
            newpath.append(path[i])
            i=i+1
        if i<len(path):               
            newpath.append(path[i])
            newpath.append(newpoint)
            while i<len(path) and lineIntersect(newpoint,path[i],rectObs,circleObs) == True:
                i=i+1
            if i<len(path):
                while i<len(path):
                    newpath.append(path[i])
                    i=i+1
                optimisePath(newpath,rectObs,circleObs)
                if pathLength(newpath)<pathLength(path):
                    allEdges[edgekey].linkPoints = newpath

def pathLength(path):
    i=0
    l=0
    while i<len(path)-1:
       l = l+dist(path[i],path[i+1])
       i = i+1
    return l

def main(group1,group2,vertices,allEdges,rectObs,circleObs,width,height):
    print('in rrt main')
    paths = {}
    pathsDone = {}
    for v1 in group1:
        for v2 in group2:
            if v1.vId<v2.vId and (str(v1.vId)+'-'+str(v2.vId)) not in allEdges: #need to find these edges
                paths[str(v1.vId)+'-'+str(v2.vId)] = []
            elif v1.vId>v2.vId and (str(v2.vId)+'-'+str(v1.vId)) not in allEdges:
                paths[str(v2.vId)+'-'+str(v1.vId)] = []                
    #count = 0 #no count - taking the points to add till you get answers then optimising with only 500 extra
    #should i be adding each point to each tree? - no need to do in tree, but optimising found paths...but yeah, these points prob could be utilised elsewhere? but that is why i have the groups
    optimiseIter = 100
    #group1,group2 - dictionaries - already have the trees or may not have been initialised yet - has to be saved
    #each time we sample a point, we connect it to each of these trees if possible, otherwise find a new point
    #but this way there could be possibility that some points left out? less possible - they are all in same region, for that to happen that new point has to be in different..
    #..region that point is useful to that vertex but not all and that is fine
    for v in group1:
        if len(group1[v]) == 0: #initialising if needed
            group1[v].append(Node(v.point,None))
    for v in group2:     
        if len(group2[v]) == 0:
            group2[v].append(Node(v.point,None))
    currentState = 'buildTree'
    
    while True:
        if currentState == 'goalFound':
            while optimiseIter>0:
                print('trying to optimise')
                newpoint = get_random_clear(width,height,rectObs,circleObs)
                optimiseFoundPaths(newpoint,allEdges,rectObs,circleObs)
                optimiseIter=optimiseIter-1
            for edgekey in paths:
                splitstr = edgekey.split('-')
                allEdges[edgekey] = geometry.Edge(vertices[int(splitstr[0])],vertices[int(splitstr[1])],paths[edgekey])
            return
            #dont need to return anything, changes made in place
        elif currentState == 'buildTree':
            print('building tree')
            res = buildTree(group1,width,height,rectObs,circleObs)
            newnode = res[0]
            parentNode = None
            #edgesChecked = {} #avoiding repetitive calculations
            for v in group2:
                for p in group2[v]:
                    if lineIntersect(newnode.point,p.point,rectObs,circleObs) == False:
                        if parentNode == None:
                            parentNode = p 
                        elif dist(p.point,newnode.point) <= dist(parentNode.point,newnode.point):
                            parentNode = p                      
                if parentNode != None:
                     for vert in res[1]:
                         if v.vId<vert.vId and (str(v.vId)+'-'+str(vert.vId)) in paths and (str(v.vId)+'-'+str(vert.vId)) not in pathsDone: #v has to be first vertex, prob wouldnt have mattered
                             currNode = parentNode
                             while currNode.parent!=None:                                               
                                 paths[str(v.vId)+'-'+str(vert.vId)].append(currNode.point)
                                 currNode = currNode.parent
                             paths[str(v.vId)+'-'+str(vert.vId)].reverse()
                             currNode = newnode
                             while currNode.parent!=None:                                               
                                 paths[str(v.vId)+'-'+str(vert.vId)].append(currNode.point)
                                 currNode = currNode.parent
                             optimisePath(paths[str(v.vId)+'-'+str(vert.vId)],rectObs,circleObs)
                             pathsDone[str(v.vId)+'-'+str(vert.vId)] = True
                         elif v.vId>vert.vId and (str(vert.vId)+'-'+str(v.vId)) in paths and (str(vert.vId)+'-'+str(v.vId)) not in pathsDone:
                             currNode = newnode
                             while currNode.parent!=None:                                               
                                 paths[str(vert.vId)+'-'+str(v.vId)].append(currNode.point)
                                 currNode = currNode.parent
                             paths[str(vert.vId)+'-'+str(v.vId)].reverse()
                             currNode = parentNode
                             while currNode.parent!=None:                                               
                                 paths[str(vert.vId)+'-'+str(v.vId)].append(currNode.point)
                                 currNode = currNode.parent
                             optimisePath(paths[str(vert.vId)+'-'+str(v.vId)],rectObs,circleObs)
                             pathsDone[str(vert.vId)+'-'+str(v.vId)] = True
                         if len(pathsDone) == len(paths):
                             #currentState = 'goalFound'
                             break
                    
            optimiseFoundPaths(newnode.point,allEdges,rectObs,circleObs)
            
            if len(pathsDone) == len(paths):
                currentState = 'goalFound'   
                
            else:
                res = buildTree(group2,width,height,rectObs,circleObs)
                newnode = res[0]
                parentNode = None
                for v in group1:
                    for p in group1[v]:
                         if lineIntersect(newnode.point,p.point,rectObs,circleObs) == False:
                            if parentNode == None:
                                parentNode = p #[p,v] 
                            elif dist(p.point,newnode.point) <= dist(parentNode.point,newnode.point):
                                parentNode = p #[p,v]                      
                    if parentNode != None:
                         #put it into paths dictionary, no need to change these (the currNode, changed and for loop after that) things - then optimise paths
                         for vert in res[1]:
                             if v.vId<vert.vId and (str(v.vId)+'-'+str(vert.vId)) in paths and (str(v.vId)+'-'+str(vert.vId)) not in pathsDone: #v has to be first vertex - actually prob wouldnt matter
                                 currNode = parentNode
                                 paths[str(v.vId)+'-'+str(vert.vId)].append(newnode.point)
                                 while currNode.parent!=None:
                                     paths[str(v.vId)+'-'+str(vert.vId)].append(currNode.point)
                                     currNode = currNode.parent
                                 paths[str(v.vId)+'-'+str(vert.vId)].reverse()
                                 currNode = newnode
                                 while currNode.parent!=None:
                                     paths[str(v.vId)+'-'+str(vert.vId)].append(currNode.point)
                                     currNode = currNode.parent
                                 optimisePath(paths[str(v.vId)+'-'+str(vert.vId)],rectObs,circleObs)
                                 pathsDone[str(vert.vId)+'-'+str(v.vId)] = True
                             elif v.vId>vert.vId and (str(vert.vId)+'-'+str(v.vId)) in paths and (str(vert.vId)+'-'+str(v.vId)) not in pathsDone:
                                 currNode = newnode
                                 paths[str(vert.vId)+'-'+str(v.vId)].append(newnode.point)
                                 while currNode.parent!=None:
                                     paths[str(vert.vId)+'-'+str(v.vId)].append(currNode.point)
                                     currNode = currNode.parent
                                 paths[str(vert.vId)+'-'+str(v.vId)].reverse()
                                 currNode = parentNode
                                 while currNode.parent!=None:                                               
                                     paths[str(vert.vId)+'-'+str(v.vId)].append(currNode.point)
                                     currNode = currNode.parent
                                 optimisePath(paths[str(vert.vId)+'-'+str(v.vId)],rectObs,circleObs)
                                 pathsDone[str(vert.vId)+'-'+str(v.vId)] = True
                             if len(pathsDone) == len(paths):
                                 break
                     
                optimiseFoundPaths(newnode.point,allEdges,rectObs,circleObs)
                 
                if len(pathsDone) == len(paths):
                     currentState = 'goalFound'
