class Node:
    def __init__(self,val,prev):
        self.val = val
        self.prev = prev
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
        self.pointer = None #this is a node
        self.size= 0 #maybe not needed
        #self.points = {}
        #self.extra = 0 #for pher?? -- keeps track of totalpher
    
    def add(self,val):
        n = Node(val,self.pointer)
        if self.head == None:
            self.head = n #self.pointer must have been none so no need to change prev
        else:
            self.pointer.next = n
            #n.prev = self.pointer # -- already done in constructor
        self.pointer = n
        self.size = self.size+1
        
    def remove(self,node):
        if node == None: #or node.next == None:
            return
        p = node.prev
        n = node.next
        if p==None and n==None:
            self.head = None
        elif p == None and n!=None:
            self.head = n
            n.prev = None 
        elif n!=None:
            p.next = n
            n.prev = p #in both cases, but not if n is None
        else: #if n == None, p!=None
            p.next = None
            self.pointer = p           
        self.size = self.size-1
        
    def copy(self):
        l = LinkedList()
        n = self.head
        while n!=None:
            l.add(n.val)
            n=n.next
        return l
        
class LinkedListPher:
    def __init__(self):
        self.head = None
        self.pointer = None #this is a node
        self.size= 0 #maybe not needed
        self.pherTotal = 0 #for pher?? -- keeps track of totalpher in cell (in this linkedlist)
    
    def add(self,val):
        n = Node(val,self.pointer)
        if self.head == None:
            self.head = n #self.pointer must have been none so no need to change prev
        else:
            self.pointer.next = n
            #n.prev = self.pointer
        self.pointer = n
        self.size = self.size+1
        self.pherTotal = self.pherTotal+val.amount
        
    def remove(self,node):
        if node == None: #or node.next == None:
            return
        p = node.prev
        n = node.next
        if p==None and n == None:
            self.head = None
        elif p == None and n!=None:
            self.head = n
            n.prev = p 
        elif n!=None:
            p.next = n
            n.prev = p #in both cases, but not if n is None
        else: #if n == None:
            p.next = n
            self.pointer = p           
        self.size = self.size-1
        #no change to pherTotal
    