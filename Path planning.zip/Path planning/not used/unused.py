#                    i=0
#                    #at each point it goes down by percentPherReduced (0.3 here)
#                    while i<len(phT)-1:
#                        #print('e')
#                        j=i
#                        count = 0
#                        while j<len(phT)-1 and phT[j][0] == phT[j+1][0] and phT[j][1] == phT[j+1][1]:
#                            #print('f')
#                            count = count+1
#                            j = j+1
#                        #print('count: ' + str(count))
#                        k = 0
#                        while k<floor(count*percentPherReduced)+1:
#                            #print('g')
#                            phT.pop(i)
#                            k = k+1
#                        i = i+count-k+1
#                    u = u+1
#                t = t+1

#def findEdge(vertices,allEdges,rectobs,circleobs,width,height):
#    #directly connectable will be done
#    #rest: have a system where all will be notified  - can be done because even non goal points have a list of goalpoints they are connected to - each time new one added, all notified
#    #each time another non goal point adds and one path already found - can check if can be made better
#    prmDict = {}
#    #allEdgeKeys = []
#    i=0
#    prmDict[vertices[i].point] = [{},{}] #goalpoints,non goal points
#    while i<len(vertices)-1:
#        j=i+1
#        while j<len(vertices):
#            prmDict[vertices[j].point] = [{},{}]
#            if lineIntersect(vertices[i].point,vertices[j].point,rectobs,circleobs) == False:
#                allEdges[str(vertices[i].vId)+'-'+str(vertices[j].vId)] = geometry.Edge(vertices[i],vertices[j],[vertices[i].point,vertices[j].point])
#                #if vertices[i].point not in prmDict:                    
#                prmDict[vertices[i].point][0][vertices[j].point] = True
#                prmDict[vertices[j].point][0][vertices[i].point] = True
#            #allEdgeKeys.append([vertices[i].point,vertices[j].point])
#            j=j+1
#        i=i+1
#    prm.main(vertices,allEdges,prmDict,rectobs,circleobs,width,height)

#def findEdge(vertices,allEdges,rectobs,circleobs,width,height):
#    print('in edgesFind findEdge')
#    i=0
#    groups = [] #array of dictionaries - in dictionary each vertex points to its tree
#    sets = {} #index of group vertex belongs to in groups
#    for v in vertices:
#        sets[v] = -1
#    while i<len(vertices)-1:
#        print('finding groups')
#        j=i+1
#        v1 = vertices[i]
#        #maybe dont check if v1,v2 already assigned sets?
#        while j<len(vertices):
#            print('finding groups 2')
#            v2 = vertices[j]
#            if lineIntersect(v1.point,v2.point,rectobs,circleobs) == False:
#                print('lineintersect false')
#                allEdges[str(v1.vId)+'-'+str(v2.vId)] = geometry.Edge(v1,v2,[v1.point,v2.point])
#                if sets[v1] == -1 and sets[v2] == -1:
#                    group = {}
#                    group[v1] = [] #initialise this as node in rrt_connect_...; basically do if u find that this array is empty
#                    group[v2] = []
#                    groups.append(group)
#                    sets[v1] = len(groups)-1
#                    sets[v2] = len(groups)-1
#                    #add new group with these 2
#                elif sets[v1] == -1:
#                    #check if v2 lineintersect with any group member
#                    group = groups[sets[v2]]
#                    canAdd = True
#                    for v in group:
#                        #actually we can just add together - the point of the group is to build trees together, not necessarily all can be directly connected
#                        if lineIntersect(v1.point,v.point,rectobs,circleobs) == True:
#                            canAdd = False
#                            break
#                    if canAdd == True:
#                        sets[v1] = sets[v2]
#                        groups[sets[v2]][v1] = []
#                    else:
#                        group = {}
#                        group[v1] = []
#                        groups.append(group)
#                        sets[v1] = len(groups)-1
#                elif sets[v2] == -1:
#                    group = groups[sets[v1]]
#                    canAdd = True
#                    for v in group:
#                        if lineIntersect(v2.point,v.point,rectobs,circleobs) == True:
#                            canAdd = False
#                            break
#                    if canAdd == True:
#                        sets[v2] = sets[v1]
#                        groups[sets[v1]][v2] = []
#                    else:
#                        group = {}
#                        group[v2] = []
#                        groups.append(group)
#                        sets[v2] = len(groups)-1
#            else:
#                print('line intersect')
#                group1 = {}
#                group2 = {}
#                group1[v1] = []
#                group2[v2] = []
#                groups.append(group1)
#                sets[v1] = len(groups)-1
#                groups.append(group2)
#                sets[v2] = len(groups)-1
#            print('next j')
#            j=j+1
#        print('next i')
#        i=i+1
#                #else:
#                    #check if all belong to same group, else keep separate group
#                    #will this case happen? - i dont think so
#    i=0
#    while i<len(groups)-1:
#        #if len(groups[i])>2:
#        print('other edges')
#        j=i+1
#        while j<len(groups): #and len(groups[j])>2: #if group doesnt have more than 2 points what are we doing?
#            print('other edges 2')
#            rrt_connect_new_edgefind.main(groups[i],groups[j],vertices,allEdges,rectobs,circleobs,width,height)
#            j=j+1
#        i=i+1

#def findEdge(v1,v2,rectobs,circleobs,width,height):
#    #from v1 to v2
#    #can do rrtconnect method also
#    if lineIntersect(v1.point,v2.point,rectobs,circleobs) == False:
#        print('direct link ' + str(v1.vId) + '-' + str(v2.vId))
#        return geometry.Edge(v1,v2,[v1.point,v2.point])
#    else:
#        print('do rrt connect ' + str(v1.vId) + '-' + str(v2.vId))
#        return rrt_connect_edgefind.main(v1,v2,rectobs,circleobs,width,height)
   
    #instead of this, find the groups, make the groups dictionary and find for each
    #groups = {} #array of dictionaries
    #we have to save this and reuse so have to make here itself

#    def findPosn(self,pheromoneTrack,x,y):
#        total = 0
#        i=0
#        while i<len(pheromoneTrack[x][y]):
#            total = total+pheromoneTrack[x][y][i].amount
#            i=i+1
#        r=random.randint(1,total)
#        curr = 0
#        i=0
#        while curr<r: #i will be lesser
#            curr = curr+pheromoneTrack[x][y][i].amount
#            i=i+1
#        return pheromoneTrack[x][y][i-1].loc
    
#class Pheromone:
#    def __init__(self,loc,amount):
#        self.loc = loc
#        self.amount = amount
    