import random
from math import *
import geometry

class Node(object):
    def __init__(self, point, parent):
        super(Node, self).__init__()
        self.point = point
        self.parent = parent
        self.srcdist = 0

delta = 25.0
GOAL_RADIUS = 10
MIN_DISTANCE_TO_ADD = 1.0
NUMNODES = 100
minImprovement = 0.0005 #0.05%

def dist(p1,p2):    #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def point_circle_collision(p1, p2, radius):
    distance = dist(p1,p2)
    if (distance <= radius):
        return True
    return False

def collides(p,rectObs,circleObs):    #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False


def lineIntersect(p1,p2,rectObs,circleObs):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False


def boundary(p,width,height):
    #print('boundary checking ' + str(p[0]) + ' ' + str(p[1]))
    if p[0]<=0 or p[0]>=width or p[1]<=0 or p[1]>=height:
        return True
    else:
        return False
    
def get_random_clear(width,height,rectObs,circleObs):
    #while True:
    p = int(random.random()*width), int(random.random()*height)
    while collides(p,rectObs,circleObs) == True or boundary(p,width,height) == True:
        p = int(random.random()*width), int(random.random()*height)
    return p
    
def step_from_to(p1,p2,rectObs,circleObs):
    #if dist(p1,p2) < delta:
    #    return None
    if lineIntersect(p1,p2,rectObs,circleObs) == False:
        return p2
    else:
        i = floor(dist(p1,p2)/delta)
        theta = atan2(p2[1]-p1[1],p2[0]-p1[0])
        while i>0:
            p = p1[0] + i*delta*cos(theta), p1[1] + i*delta*sin(theta)
            if collides(p,rectObs,circleObs) == False and lineIntersect(p1,p,rectObs,circleObs) == False:
                return p
            else:
                i = i-1       
        return None

def buildTree(nodes,width,height,rectObs,circleObs):
    foundNext = False
    #print('a')
    while foundNext == False:
        #print('b')
        rand = get_random_clear(width,height,rectObs,circleObs)
        #rand = get_random_clear_spl(nodes[0].point,4)
        #pygame.draw.circle(screen, black, rand, SAMPLE_RADIUS)
        parentNode = None
        for p in nodes:
            #print('c')
            newPoint = step_from_to(p.point,rand,rectObs,circleObs)
            if newPoint != None:
                if parentNode == None:
                    #print('d')
                    parentNode = p
                    foundNext = True
                if dist(p.point,rand) < dist(parentNode.point,rand):  
                    #print('e')
                    parentNode = p
                    foundNext = True
    #print('f')
    newpoint = step_from_to(parentNode.point,rand,rectObs,circleObs)
    newNode = Node(newpoint, parentNode)
    newNode.srcdist = parentNode.srcdist + dist(newNode.point,parentNode.point)
    nodes.append(newNode)
    #pygame.draw.line(screen,cyan,parentNode.point,newpoint)
    return nodes

def optimisePath(path,rectObs,circleObs):
    optimised = True       
    while optimised == True:
        i=len(path)-2
        optimised = False
        print("optimising " + str(len(path)))            
        while i>1: #at least index i equal to 2 (3 needed for triangulation)
            #print("not reached start node, trying to optimise")
            while i>1 and lineIntersect(path[i],path[i-2],rectObs,circleObs) == False:
                #print("can optimise here")
                path.pop(i-1)
                i = i-1 #new position of i
                #print('i = ' + str(i))
                optimised = True #is setting again and again using too much memory?
            i=i-1
            
    #finding btr non goal points
    numiter = 5
    #mindiff = 0.05
    index=1
    while index<len(path)-1:
        min1 = 0.0
        max1 = 1.0
        min2 = 0.0
        max2 = 1.0 #we prob don't need all, can initiate again after this loop
        for k in range(numiter):
            if min1==max1:
                break
            r = round(random.uniform(min1, max1),3)
            newPoint = int((1-r)*path[index-1][0]+r*path[index][0]) , int((1-r)*path[index-1][1]+r*path[index][1])
            if lineIntersect(newPoint, path[index+1], rectObs, circleObs) == True:
                #if r<max1: #always true, that's where we found r
                min1 = r                   
            elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                print("line 1 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                path[index] = newPoint                  
                max1 = r
        for k in range(numiter):
            if min2==max2:
                break
            r = round(random.uniform(min2, max2),3)
            newPoint = int((1-r)*path[index+1][0]+r*path[index][0]) , int((1-r)*path[index+1][1]+r*path[index][1])
            if lineIntersect(newPoint, path[index-1], rectObs, circleObs) == True:
                #if r<max1: #always true, that's where we found r
                min2 = r
            elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                print("line 2 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                path[index] = newPoint                  
                max2 = r
        index = index+1

def pathLength(path):
    i=0
    l=0
    while i<len(path)-1:
       l = l+dist(path[i],path[i+1]) 
       i=i+1
    return l

def main(v1,v2,rectObs,circleObs,width,height):
    print('in rrt main')
    count = 0
    optimiseIter = 10
    reachedGoal = Node(None, None)
    initialPoint = Node(v1.point,None)
    goalPoint = Node(v2.point,None)
    nodes1 = [initialPoint]
    nodes2 = [goalPoint]
    path = []
    currentState = 'buildTree'
    
    while True:
        if currentState == 'goalFound':
            #global optimiseIter
            if optimiseIter > 0:
                currNode = reachedGoal
                oldGoal = None
                #pygame.display.set_caption('Goal Reached, dist = ' + str(reachedGoal.srcdist))
                print ("Path found") 
                print (len(nodes1))
                while currNode.parent != None:
                    print('tracing path')
                    #pygame.draw.line(screen,red,currNode.point,currNode.parent.point)
                    currNode = currNode.parent
                    path.append(currNode.point)
                #time.sleep(0.01)
                optimisePath(path,rectObs,circleObs)
                reachedGoal.srcdist = pathLength(path)
                count = count+1
                if count<NUMNODES:
                    print('optimising further')
                    nodes1 = buildTree(nodes1,width,height,rectObs,circleObs)
                    newNode = nodes1[len(nodes1)-1]
                    if point_circle_collision(newNode.point, goalPoint.point, GOAL_RADIUS):
                        currentState = 'goalFound'
                        newPath = []
                        #mayben should do rrt star step here? only considering if new point is in that area, we should check if new path possible
                        #or maybe if collision with goalpoint detected, check that also
                        currNode = newNode
                        while currNode.parent != None:
                            print('tracing path 2')
                            #pygame.draw.line(screen,red,currNode.point,currNode.parent.point)
                            currNode = currNode.parent
                            newPath.append(currNode.point)
                        #time.sleep(0.01)
                        optimisePath(newPath,rectObs,circleObs)
                        newNode.srcdist = pathLength(newPath)
                        if reachedGoal.srcdist >= newNode.srcdist:
                            oldGoal = reachedGoal
                            reachedGoal = newNode
                            path = newPath
                if oldGoal != None and (oldGoal.srcdist-reachedGoal.srcdist)/oldGoal.srcdist>=minImprovement:
                    optimiseIter = 0
                else:
                    optimiseIter = optimiseIter-1
                #optimizePhase = True
                return geometry.Edge(v1,v2,path)
        elif currentState == 'buildTree':
            count = count+1
            print('building tree')
            #pygame.display.set_caption('Performing RRT connect')
            if count < NUMNODES:
                nodes1 = buildTree(nodes1,width,height,rectObs,circleObs)
                newnode = nodes1[len(nodes1)-1]
                parentNode = None
                for p in nodes2:
                    if lineIntersect(newnode.point,p.point,rectObs,circleObs) == False:
                        if parentNode == None:
                            parentNode = p 
                        elif dist(p.point,newnode.point) <= dist(parentNode.point,newnode.point):
                            parentNode = p                      
                if parentNode != None:
                     #pygame.draw.line(screen,cyan,parentNode.point,newnode.point)                    
                     currNode = parentNode
                     currNodeParent = parentNode.parent
                     parentNode.parent = newnode
                     parentNode.srcdist = newnode.srcdist + dist(parentNode.point,newnode.point)                     
                     while currNodeParent!=None:
                         temp = currNodeParent.parent
                         currNodeParent.parent = currNode
                         currNodeParent.srcdist = currNodeParent.parent.srcdist + dist(currNodeParent.point,currNodeParent.parent.point)
                         currNode = currNodeParent
                         currNodeParent = temp
                     
                     changed = True
                     while changed == True:
                        #print('hi')
                        changed = False
                        for n in nodes2:
                            if n.parent != None:
                                old = n.srcdist
                                n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                if n.srcdist!=old:
                                    changed = True
                     
                     for n in nodes2:
                        nodes1.append(n)
                     #optimisePath(path,rectObs,circleObs)                     
                     currentState = 'goalFound'
                     reachedGoal = goalPoint
                
                else:
                   count = count+1 
                   if count < NUMNODES:
                        nodes2 = buildTree(nodes2,width,height,rectObs,circleObs)
                        newnode = nodes2[len(nodes2)-1]
                        parentNode = None
                        for p in nodes1:
                            if lineIntersect(newnode.point,p.point,rectObs,circleObs) == False:
                                if parentNode == None:
                                    parentNode = p 
                                elif dist(p.point,newnode.point) <= dist(parentNode.point,newnode.point):
                                    parentNode = p 
                        if parentNode != None:
                             #pygame.draw.line(screen,cyan,parentNode.point,newnode.point)                    
                             currNode = newnode
                             currNodeParent = newnode.parent
                             newnode.parent = parentNode
                             newnode.srcdist = parentNode.srcdist + dist(parentNode.point,newnode.point)                     
                             while currNodeParent!=None:
                                 temp = currNodeParent.parent
                                 currNodeParent.parent = currNode
                                 currNodeParent.srcdist = currNodeParent.parent.srcdist + dist(currNodeParent.point,currNodeParent.parent.point)
                                 currNode = currNodeParent
                                 currNodeParent = temp
                             
                             changed = True
                             while changed == True:
                                #print('hello')
                                changed = False
                                for n in nodes2:
                                    if n.parent != None:
                                        old = n.srcdist
                                        n.srcdist = n.parent.srcdist + dist(n.point,n.parent.point)
                                        if n.srcdist!=old:
                                            changed = True
                             
                             for n in nodes2:
                                nodes1.append(n)
                             #optimisePath(path,rectObs,circleObs)
                             currentState = 'goalFound'
                             reachedGoal = goalPoint
            
            else:
                #print("Ran out of nodes... :(")
                #return;
                count = 0

#if __name__ == '__main__':
#    main()
