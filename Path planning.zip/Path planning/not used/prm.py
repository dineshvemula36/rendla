import random, queue
import geometry
from math import *
from pygame import *

def dist(p1,p2):    #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

def point_circle_collision(p1, p2, radius):
    if dist(p1,p2) <= radius:
        return True
    return False

def collides(p,rectObs,circleObs): #check if point collides with the obstacle
    for rect in rectObs:
        if rect.collidepoint(p) == True:
            return True
    for circle in circleObs:
        if dist((circle[0],circle[1]),p) <= circle[2]:
            return True
    return False

def lineIntersect(p1,p2,rectObs,circleObs):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False

def get_random_clear(width,height,rectObs,circleObs):
    #while True:
    p = int(random.random()*width), int(random.random()*height)
    while collides(p,rectObs,circleObs) == True or boundary(p,width,height) == True:
        p = int(random.random()*width), int(random.random()*height)
    return p

def boundary(p,width,height):
    #print('boundary checking ' + str(p[0]) + ' ' + str(p[1]))
    if p[0]<=0 or p[0]>=width or p[1]<=0 or p[1]>=height:
        return True
    else:
        return False

def optimisePath(path,rectObs,circleObs):
    optimised = True
    while optimised == True:
        i=len(path)-2
        optimised = False
        print("optimising " + str(len(path)))
        while i>1: #at least index i equal to 2 (3 needed for triangulation)
            #print("not reached start node, trying to optimise")
            while i>1 and lineIntersect(path[i],path[i-2],rectObs,circleObs) == False:
                #print("can optimise here")
                path.pop(i-1)
                i = i-1 #new position of i
                #print('i = ' + str(i))
                optimised = True #is setting again and again using too much memory?
            i=i-1
            
    #finding btr non goal points
    numiter = 5
    #mindiff = 0.05
    index=1
    while index<len(path)-1:
        min1 = 0.0
        max1 = 1.0
        min2 = 0.0
        max2 = 1.0 #we prob don't need all, can initiate again after this loop
        for k in range(numiter):
            if min1==max1:
                break
            r = round(random.uniform(min1, max1),3)
            newPoint = int((1-r)*path[index-1][0]+r*path[index][0]) , int((1-r)*path[index-1][1]+r*path[index][1])
            if lineIntersect(newPoint, path[index+1], rectObs, circleObs) == True:
                #if r<max1: #always true, that's where we found r
                min1 = r                   
            elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                print("line 1 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                path[index] = newPoint                  
                max1 = r
        for k in range(numiter):
            if min2==max2:
                break
            r = round(random.uniform(min2, max2),3)
            newPoint = int((1-r)*path[index+1][0]+r*path[index][0]) , int((1-r)*path[index+1][1]+r*path[index][1])
            if lineIntersect(newPoint, path[index-1], rectObs, circleObs) == True:
                #if r<max1: #always true, that's where we found r
                min2 = r
            elif dist(newPoint,path[index-1])+dist(newPoint,path[index+1])<dist(path[index],path[index-1])+dist(path[index],path[index+1]): #boundary, collides, contains should not happen
                print("line 2 found btr nongoal pt " + str(-dist(newPoint,path[index-1])-dist(newPoint,path[index+1])+dist(path[index],path[index-1])+dist(path[index],path[index+1])))
                path[index] = newPoint
                max2 = r
        index = index+1
        
def edgesContains(v1,v2,allEdges):
    if v1.vId<v2.vId and (str(v1.vId)+'-'+str(v2.vId)) in allEdges:
        return True
    elif v1.vId>v2.vId and (str(v2.vId)+'-'+str(v1.vId)) in allEdges:
        return True
    return False

def addEdge(v1,v2,allEdges,path):
    if v1.vId<v2.vId and (str(v1.vId)+'-'+str(v2.vId)) in allEdges:
        allEdges[str(v1.vId)+'-'+str(v2.vId)] = geometry.Edge(v1,v2,path)
    else:
        allEdges[str(v2.vId)+'-'+str(v1.vId)] = geometry.Edge(v2,v1,path)

def pathLength(path):
    i=0
    l=0
    while i<len(path)-1:
       l = l+dist(path[i],path[i+1])
       i = i+1
    return l

def getEdge(v1,v2,allEdges):
    print('get edge')
    if v1.vId<v2.vId and (str(v1.vId)+'-'+str(v2.vId)) in allEdges:
        return allEdges[str(v1.vId)+'-'+str(v2.vId)]
    else:
        return allEdges[str(v2.vId)+'-'+str(v1.vId)]
    
def findPath(p,g1,g2,connectedgoalps,connectednongoalps):
    print('finding path [] thru new point')
    path = []
    current = g1
    while current[0] != p[0] or current[1] != p[1]:
        path.append(current)
        if current in connectedgoalps:
            current = connectedgoalps[current]
        else: #has to be in connectednongoalps
            current = connectednongoalps[current]
    path.append(p) #broke out of loop before p was added
    partpath = []
    current = g2
    while current[0] != p[0] or current[1] != p[1]:
        partpath.append(current)
        if current in connectedgoalps:
            current = connectedgoalps[current]
        else: #has to be in connectednongoalps
            current = connectednongoalps[current]
    i=len(partpath)-1 #we dont want r to be included twice -- actually it hasnt been we break out of loop before that
    while i>-1:
        path.append(partpath[i])
        i = i-1
    return path

def connections(r,q,prmDict,visited,allEdges,connectedgoalps,connectednongoalps,goalPoints,rectObs,circleObs):
   if q.qsize() == 0:
       print('q is empty')
       return
   p = q.get() #use queue and dequeue here
   if p in visited: #which means visited[p] = True
       print('p was visited')
       return
   visited[p] = True
   #find new goalpoints that are connected - check in goalps already there and connect ones not already connected
   #optimisation?? the ones that have been connected before, need the path to these goalps from this one too
   #connectedgoalps is a dictionary of goalps - but how do we get path?? we can definitely get the 1 point that came to this goalp -- if that is a goalp look in connectedgoalps only
   #else in connectednongoalps
   for g in prmDict[p][0]:
       if g not in connectedgoalps:
           connectedgoalps[g] = p
           q.put(g)
           #check if any new goalp connection
           for g1 in connectedgoalps:
               #if edgesContains(goalPoints[g],goalPoints[g1],allEdges) == False: #figure out how to do for points not vertices #maybe in the goalPoint dictionary in main function, make point point to vertex
                   #add new edge
               print('finding path thru this point')
               path = findPath(r,g,g1,connectedgoalps,connectednongoalps) #r is the common point we want to find .. not p
               optimisePath(path,rectObs,circleObs)
               if edgesContains(goalPoints[g],goalPoints[g1],allEdges) == False or pathLength(getEdge(goalPoints[g],goalPoints[g1],allEdges).linkPoints)>pathLength(path):
                   print('found new path or btr path')
                   addEdge(goalPoints[g],goalPoints[g1],allEdges,path)
                   #check optimisation by finding path to p from each (getting that array) and then optimising the path and finding if it is btr than one we have
                   #we actually dont need if else, in both cases we add - if it dsnt exist just add, if it does, check if smaller           
   for ng in prmDict[p][1]:
       if ng not in connectednongoalps:
           connectednongoalps[ng] = p
           q.put(ng)
    #now next recursive call for next level - before that add children to point to p
   connections(r,q,prmDict,visited,allEdges,connectedgoalps,connectednongoalps,goalPoints,rectObs,circleObs)    

def main(vertices,allEdges,prmDict,rectObs,circleObs,width,height): 
    n = len(vertices)
    totalEdges = int(n*(n-1)/2)
    #make a dict of vertices poitns also to find if goalpoint
    #prmDict has points as keys, even for goalpoints
    goalPoints = {}
    for v in vertices:
        goalPoints[v.point] = v
    optimisePoints = 500
    while len(allEdges)<totalEdges or optimisePoints>0:
        print('adding new point')
        r = get_random_clear(width,height,rectObs,circleObs)
        toAdd = False
        goalps = {}
        nongoalps = {}
        for p in prmDict:
            print('checking for r..')
            if lineIntersect(r,p,rectObs,circleObs) == False:
                print('found 1 point for r')
                toAdd = True
                prmDict[p][1][r] = True
                if p in goalPoints:
                    print('was goal p')
                    goalps[p] = True
                else:
                    print('was non goal p')
                    nongoalps[p] = True
                #but we can use it to optimise all paths formed by paths involving any 2 points that are connected to it, not just newly joined points
                #already joined points do optimise function specifically maybe, the other one is being used to make new edges -- we only need to optimise found paths, not anything else so check if this point can do that, that's all
        if toAdd == True:
            prmDict[r] = [goalps,nongoalps]
            print('add r and do bfs')
            visited = {}
            q = queue.Queue(maxsize=5000)
            q.put(r)
            connections(r,q,prmDict,visited,allEdges,{},{},goalPoints,rectObs,circleObs)
            if len(allEdges) == totalEdges:
                print('r was optimising point')
                optimisePoints = optimisePoints-1
            #check for newly joined goalps directly, newly joined non goal points or 1 goal point to non goal point - check if any goalpoints connected to them joined
            #check for non matching goalps among the non goal ps and check if already connected -- but then we can keep repeating this -- going to next set of non goal ps too
        #basically check if it joined 2 goalps that were not joined before, or 2 nongoalps that were not joined before...wt abt 1 goalp and 1 nongoalp?? -- that also
        #if none of this happened, don't add?? no, let it stay, it could be useful later, esp if too many points havent been sampled yet
        #basically check if there is any pair of points (goalp or nongoalp) that were joined newly bcos of this..get that and try to connect goalps of those       
        #bfs better or dfs? we are also searching for diff things -- why are we doing a kind of bfs here -- bcos best case is btr here, for dfs best and worst case are same
        #or saving indirect goalps too, first time we'll have to do some searching then store, but this will get updated too right? - can go thru nongoalps and update
        #now connect all the goalps
        #for g in goalps: 
            #this could be connector between 2 goalps (3 points in path), can also get to goalpoints connected to these adn so one, can go into this loop too
            #or actually just go thru every point in prmDict to find which ones.,. - already done, this step is to find the edges made
            #what we can do instead is check if one of the paths has been made by adding this point - if it is a path that exists in allEdges, check if btr path else add path
            #but this only connects if this is only non goal point - what about others
            #cant just do for goalps, have to do for nongoalps as well each time, and check if possible to connect at some stage - will this become never ending loop? -- no have visited dictionary
